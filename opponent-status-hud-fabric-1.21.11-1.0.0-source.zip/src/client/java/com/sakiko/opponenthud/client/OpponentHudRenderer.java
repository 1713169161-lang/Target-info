package com.sakiko.opponenthud.client;

import java.util.Locale;
import java.util.UUID;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import org.jspecify.annotations.Nullable;

final class OpponentHudRenderer implements HudElement {
	static final int PANEL_WIDTH = 230;
	static final int PANEL_HEIGHT = 62;

	private static final int HEAD_SIZE = 38;
	private static final int BAR_WIDTH = 168;
	private static final int HEAD_BACKGROUND = 0xFF0A0D10;
	private static final int HEAD_BORDER = 0xFF4A5863;
	private static final int TEXT = 0xFFF5F7F8;
	private static final int MUTED_TEXT = 0xFFB8C3C9;
	private static final int HEALTH = 0xFF18C7D9;
	private static final int HEALTH_MEDIUM = 0xFFFFB300;
	private static final int HEALTH_LOW = 0xFFEF5350;
	private static final int ABSORPTION = 0xFFFFC43D;
	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD,
			EquipmentSlot.CHEST,
			EquipmentSlot.LEGS,
			EquipmentSlot.FEET
	};

	private final TargetTracker targetTracker;
	private final HudConfig config;
	private @Nullable HudData lastRenderedData;
	private @Nullable UUID smoothedTargetId;
	private float visibility;
	private float displayedHealth;

	OpponentHudRenderer(TargetTracker targetTracker, HudConfig config) {
		this.targetTracker = targetTracker;
		this.config = config;
	}

	@Override
	public void render(DrawContext context, RenderTickCounter tickCounter) {
		MinecraftClient client = MinecraftClient.getInstance();
		LivingEntity target = targetTracker.getTarget();
		boolean shouldShow = target != null && MinecraftClient.isHudEnabled() && client.player != null;
		float delta = MathHelper.clamp(tickCounter.getDynamicDeltaTicks(), 0.0F, 5.0F);

		if (shouldShow) {
			lastRenderedData = smoothHealth(target.getUuid(), HudData.fromEntity(target), delta);
		}
		if (lastRenderedData == null) {
			return;
		}

		float response = shouldShow ? 0.32F : 0.24F;
		float progress = 1.0F - (float) Math.exp(-response * delta);
		visibility = MathHelper.lerp(progress, visibility, shouldShow ? 1.0F : 0.0F);
		if (visibility <= 0.01F) {
			visibility = 0.0F;
			if (!shouldShow) {
				lastRenderedData = null;
			}
			return;
		}

		renderConfigured(context, lastRenderedData, config, visibility);
	}

	void renderPreview(DrawContext context, HudConfig previewConfig) {
		LivingEntity target = targetTracker.getTarget();
		if (target == null) {
			target = MinecraftClient.getInstance().player;
		}
		renderConfigured(context, target == null ? HudData.sample() : HudData.fromEntity(target), previewConfig, 1.0F);
	}

	void clampPosition(HudConfig targetConfig, int screenWidth, int screenHeight) {
		targetConfig.setX(MathHelper.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth)));
		if (targetConfig.y() >= 0) {
			targetConfig.setY(MathHelper.clamp(targetConfig.y(), 0, maxLogicalY(targetConfig, screenHeight)));
		}
	}

	int logicalX(HudConfig targetConfig, int screenWidth) {
		return MathHelper.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth));
	}

	int logicalY(HudConfig targetConfig, int screenHeight) {
		int y = targetConfig.y() < 0 ? maxLogicalY(targetConfig, screenHeight) / 2 : targetConfig.y();
		return MathHelper.clamp(y, 0, maxLogicalY(targetConfig, screenHeight));
	}

	int maxLogicalX(HudConfig targetConfig, int screenWidth) {
		return Math.max(0, (int) (screenWidth / targetConfig.scale()) - PANEL_WIDTH);
	}

	int maxLogicalY(HudConfig targetConfig, int screenHeight) {
		return Math.max(0, (int) (screenHeight / targetConfig.scale()) - PANEL_HEIGHT);
	}

	int renderedX(HudConfig targetConfig, int screenWidth) {
		return Math.round(logicalX(targetConfig, screenWidth) * targetConfig.scale());
	}

	int renderedY(HudConfig targetConfig, int screenHeight) {
		return Math.round(logicalY(targetConfig, screenHeight) * targetConfig.scale());
	}

	int renderedWidth(HudConfig targetConfig) {
		return Math.round(PANEL_WIDTH * targetConfig.scale());
	}

	int renderedHeight(HudConfig targetConfig) {
		return Math.round(PANEL_HEIGHT * targetConfig.scale());
	}

	private static void renderConfigured(DrawContext context, HudData data, HudConfig targetConfig, float visibility) {
		float scale = targetConfig.scale();
		int scaledWidth = Math.max(PANEL_WIDTH, (int) (context.getScaledWindowWidth() / scale));
		int scaledHeight = Math.max(PANEL_HEIGHT, (int) (context.getScaledWindowHeight() / scale));
		int x = MathHelper.clamp(targetConfig.x(), 0, scaledWidth - PANEL_WIDTH);
		int requestedY = targetConfig.y() < 0 ? scaledHeight / 2 - PANEL_HEIGHT / 2 : targetConfig.y();
		int y = MathHelper.clamp(requestedY, 0, scaledHeight - PANEL_HEIGHT);
		TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;

		context.getMatrices().pushMatrix();
		context.getMatrices().scale(scale, scale);
		float easedVisibility = easeOutCubic(visibility);
		float centerX = x + PANEL_WIDTH / 2.0F;
		float centerY = y + PANEL_HEIGHT / 2.0F;
		context.getMatrices().translate(centerX - (1.0F - easedVisibility) * 12.0F, centerY);
		context.getMatrices().scale(0.90F + easedVisibility * 0.10F, 0.90F + easedVisibility * 0.10F);
		context.getMatrices().translate(-centerX, -centerY);

		SimpleStyle style = SimpleStyle.of(visibility);
		drawHead(context, textRenderer, data, x + 8, y + 12, style);
		drawNameAndHealth(context, textRenderer, data.name(), data.health(), data.maxHealth(), data.absorption(), x + 55, y + 8, style);
		drawHealthBar(context, data.health(), data.maxHealth(), data.absorption(), x + 55, y + 23, style);
		drawEquipment(context, textRenderer, data.owner(), data.armor(), data.mainHand(), data.offHand(), x + 55, y + 38);
		context.getMatrices().popMatrix();
	}

	private static void drawHead(DrawContext context, TextRenderer textRenderer, HudData data, int x, int y, SimpleStyle style) {
		context.fill(x - 2, y - 2, x + HEAD_SIZE + 2, y + HEAD_SIZE + 2, style.headBackground());
		drawOutline(context, x - 1, y - 1, HEAD_SIZE + 2, HEAD_SIZE + 2, style.headBorder());
		if (data.skin() != null) {
			PlayerSkinDrawer.draw(context, data.skin(), x, y, HEAD_SIZE);
			return;
		}

		context.fill(x + 3, y + 3, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, multiplyAlpha(0xFF18232B, style.contentAlpha()));
		context.fill(x + 3, y + HEAD_SIZE - 7, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, multiplyAlpha(data.entityAccent(), style.contentAlpha()));
		context.drawCenteredTextWithShadow(textRenderer, entityInitial(data.name()), x + HEAD_SIZE / 2, y + 13, style.text());
	}

	private static void drawNameAndHealth(DrawContext context, TextRenderer textRenderer, String targetName, float health, float maxHealth, float absorption, int x, int y, SimpleStyle style) {
		String healthText = absorption > 0.0F
				? formatHealth(health) + " +" + formatHealth(absorption)
				: formatHealth(health) + " / " + formatHealth(maxHealth);
		int healthWidth = textRenderer.getWidth(healthText);
		String name = ellipsize(textRenderer, targetName, Math.max(20, BAR_WIDTH - healthWidth - 8));

		context.drawText(textRenderer, name, x, y, style.text(), true);
		context.drawText(textRenderer, healthText, x + BAR_WIDTH - healthWidth, y, style.mutedText(), false);
	}

	private static void drawHealthBar(DrawContext context, float health, float maxHealth, float absorption, int x, int y, SimpleStyle style) {
		float safeHealth = Math.max(0.0F, health);
		float safeMaxHealth = Math.max(1.0F, maxHealth);
		float safeAbsorption = Math.max(0.0F, absorption);
		float scaleMax = safeMaxHealth + safeAbsorption;
		int healthWidth = MathHelper.clamp(Math.round(BAR_WIDTH * safeHealth / scaleMax), 0, BAR_WIDTH);
		int absorptionWidth = MathHelper.clamp(Math.round(BAR_WIDTH * safeAbsorption / scaleMax), 0, BAR_WIDTH - healthWidth);
		float healthRatio = safeHealth / safeMaxHealth;
		int healthColor = healthRatio <= 0.25F ? HEALTH_LOW : healthRatio <= 0.5F ? HEALTH_MEDIUM : HEALTH;

		if (healthWidth > 0) {
			context.fill(x, y, x + healthWidth, y + 7, multiplyAlpha(healthColor, style.contentAlpha()));
		}
		if (absorptionWidth > 0) {
			context.fill(x + healthWidth, y, x + healthWidth + absorptionWidth, y + 7, multiplyAlpha(ABSORPTION, style.contentAlpha()));
		}
	}

	private static void drawEquipment(DrawContext context, TextRenderer textRenderer, @Nullable LivingEntity owner, ItemStack[] armor, ItemStack mainHand, ItemStack offHand, int x, int y) {
		int itemIndex = 1;
		for (int index = 0; index < armor.length; index++) {
			drawItem(context, textRenderer, owner, armor[index], x + index * 22, y, itemIndex++);
		}
		drawItem(context, textRenderer, owner, mainHand, x + armor.length * 22, y, itemIndex++);
		drawItem(context, textRenderer, owner, offHand, x + (armor.length + 1) * 22, y, itemIndex);
	}

	private static void drawItem(DrawContext context, TextRenderer textRenderer, @Nullable LivingEntity owner, ItemStack stack, int x, int y, int itemIndex) {
		if (stack.isEmpty()) {
			return;
		}
		if (owner == null) {
			context.drawItem(stack, x, y, itemIndex);
		} else {
			context.drawItem(owner, stack, x, y, itemIndex);
		}
		context.drawStackOverlay(textRenderer, stack, x, y);
	}

	private HudData smoothHealth(UUID targetId, HudData data, float delta) {
		if (!targetId.equals(smoothedTargetId)) {
			smoothedTargetId = targetId;
			displayedHealth = data.health();
		} else if (data.health() < displayedHealth) {
			float progress = 1.0F - (float) Math.exp(-0.24F * delta);
			displayedHealth = MathHelper.lerp(progress, displayedHealth, data.health());
		} else {
			displayedHealth = data.health();
		}
		return data.withHealth(displayedHealth);
	}

	private static void drawOutline(DrawContext context, int x, int y, int width, int height, int color) {
		context.fill(x, y, x + width, y + 1, color);
		context.fill(x, y + height - 1, x + width, y + height, color);
		context.fill(x, y, x + 1, y + height, color);
		context.fill(x + width - 1, y, x + width, y + height, color);
	}

	private static float easeOutCubic(float value) {
		float inverse = 1.0F - MathHelper.clamp(value, 0.0F, 1.0F);
		return 1.0F - inverse * inverse * inverse;
	}

	private static int multiplyAlpha(int color, float amount) {
		int alpha = Math.round((color >>> 24) * MathHelper.clamp(amount, 0.0F, 1.0F));
		return alpha << 24 | color & 0x00FFFFFF;
	}

	private static String ellipsize(TextRenderer textRenderer, String text, int maxWidth) {
		if (textRenderer.getWidth(text) <= maxWidth) {
			return text;
		}
		String suffix = "...";
		return textRenderer.trimToWidth(text, Math.max(0, maxWidth - textRenderer.getWidth(suffix))) + suffix;
	}

	private static String formatHealth(float value) {
		float rounded = Math.round(value * 10.0F) / 10.0F;
		return rounded == (int) rounded ? Integer.toString((int) rounded) : Float.toString(rounded);
	}

	private static String entityInitial(String name) {
		return name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
	}

	private static int entityAccent(LivingEntity entity) {
		int hash = entity.getType().getTranslationKey().hashCode();
		return 0xFF000000 | 0x60 << 16 | ((hash >>> 8) & 0x7F) << 8 | (0x80 | hash & 0x7F);
	}

	private record SimpleStyle(int headBackground, int headBorder, int text, int mutedText, float contentAlpha) {
		private static SimpleStyle of(float visibility) {
			float alpha = MathHelper.clamp(visibility, 0.0F, 1.0F);
			return new SimpleStyle(
					multiplyAlpha(HEAD_BACKGROUND, alpha),
					multiplyAlpha(HEAD_BORDER, alpha),
					multiplyAlpha(TEXT, alpha),
					multiplyAlpha(MUTED_TEXT, alpha),
					alpha
			);
		}
	}

	private record HudData(
			@Nullable LivingEntity owner,
			String name,
			@Nullable SkinTextures skin,
			int entityAccent,
			float health,
			float maxHealth,
			float absorption,
			ItemStack[] armor,
			ItemStack mainHand,
			ItemStack offHand
	) {
		private HudData withHealth(float health) {
			return new HudData(owner, name, skin, entityAccent, health, maxHealth, absorption, armor, mainHand, offHand);
		}

		private static HudData fromEntity(LivingEntity entity) {
			ItemStack[] armor = new ItemStack[ARMOR_SLOTS.length];
			for (int index = 0; index < ARMOR_SLOTS.length; index++) {
				armor[index] = entity.getEquippedStack(ARMOR_SLOTS[index]);
			}
			SkinTextures skin = entity instanceof AbstractClientPlayerEntity player ? player.getSkin() : null;
			return new HudData(
					entity,
					entity.getName().getString(),
					skin,
					OpponentHudRenderer.entityAccent(entity),
					Math.max(0.0F, entity.getHealth()),
					Math.max(1.0F, entity.getMaxHealth()),
					Math.max(0.0F, entity.getAbsorptionAmount()),
					armor,
					entity.getMainHandStack(),
					entity.getOffHandStack()
			);
		}

		private static HudData sample() {
			return new HudData(
					null,
					"Target",
					null,
					0xFF18C7D9,
					17.0F,
					20.0F,
					2.0F,
					new ItemStack[]{
						damaged(Items.DIAMOND_HELMET, 0.15F),
						damaged(Items.DIAMOND_CHESTPLATE, 0.35F),
						damaged(Items.DIAMOND_LEGGINGS, 0.55F),
						damaged(Items.DIAMOND_BOOTS, 0.75F)
					},
					damaged(Items.DIAMOND_SWORD, 0.2F),
					damaged(Items.SHIELD, 0.35F)
			);
		}

		private static ItemStack damaged(Item item, float damageRatio) {
			ItemStack stack = new ItemStack(item);
			stack.setDamage(Math.round(stack.getMaxDamage() * damageRatio));
			return stack;
		}
	}
}
