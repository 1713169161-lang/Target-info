package com.sakiko.opponenthud.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.hit.EntityHitResult;

final class TargetTracker {
	private final HudConfig config;
	private LivingEntity target;
	private int ticksRemaining;
	private boolean enabled = true;

	TargetTracker(HudConfig config) {
		this.config = config;
	}

	void tick(MinecraftClient client) {
		if (client.world == null || client.player == null) {
			clear();
			return;
		}

		if (client.crosshairTarget instanceof EntityHitResult hitResult && isValidTarget(hitResult.getEntity(), client)) {
			focus((LivingEntity) hitResult.getEntity());
			return;
		}

		if (ticksRemaining > 0) {
			ticksRemaining--;
		}
		if (ticksRemaining <= 0 || target == null || target.isRemoved() || target.getEntityWorld() != client.world) {
			clear();
		}
	}

	void focus(LivingEntity entity) {
		target = entity;
		ticksRemaining = config.retainTicks();
	}

	LivingEntity getTarget() {
		return enabled ? target : null;
	}

	boolean isEnabled() {
		return enabled;
	}

	void toggle() {
		enabled = !enabled;
	}

	static boolean isValidTarget(Entity entity, MinecraftClient client) {
		return entity instanceof LivingEntity
				&& entity != client.player
				&& !(entity instanceof ArmorStandEntity)
				&& !entity.isSpectator();
	}

	private void clear() {
		target = null;
		ticksRemaining = 0;
	}
}
