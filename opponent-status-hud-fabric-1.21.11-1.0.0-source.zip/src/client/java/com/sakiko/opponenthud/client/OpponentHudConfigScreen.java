package com.sakiko.opponenthud.client;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.cursor.StandardCursors;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

final class OpponentHudConfigScreen extends Screen {
	private static final int CONTROL_PANEL_WIDTH = 268;
	private static final int CONTROL_PANEL_HEIGHT = 157;
	private static final int CONTROL_MARGIN = 12;
	private static final int CONTROL_GAP = 5;

	private final Screen parent;
	private final HudConfig savedConfig;
	private final HudConfig workingConfig;
	private final OpponentHudRenderer renderer;

	private ConfigSlider xSlider;
	private ConfigSlider ySlider;
	private ConfigSlider scaleSlider;
	private ConfigSlider retainSlider;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private boolean draggingPreview;
	private double dragOffsetX;
	private double dragOffsetY;

	OpponentHudConfigScreen(Screen parent, HudConfig config, OpponentHudRenderer renderer) {
		super(Text.translatable("screen.opponenthud.config"));
		this.parent = parent;
		this.savedConfig = config;
		this.workingConfig = config.copy();
		this.renderer = renderer;
	}

	@Override
	protected void init() {
		panelWidth = Math.min(CONTROL_PANEL_WIDTH, width - CONTROL_MARGIN * 2);
		panelX = Math.max(CONTROL_MARGIN, width - panelWidth - CONTROL_MARGIN);
		panelY = CONTROL_MARGIN;
		int sliderX = panelX + 10;
		int sliderWidth = panelWidth - 20;
		int sliderY = panelY + 27;

		xSlider = addDrawableChild(new ConfigSlider(
				sliderX, sliderY, sliderWidth, () -> 0.0,
				() -> renderer.maxLogicalX(workingConfig, width), renderer.logicalX(workingConfig, width),
				value -> workingConfig.setX((int) Math.round(value)),
				value -> Text.translatable("option.opponenthud.x", Math.round(value))
		));
		ySlider = addDrawableChild(new ConfigSlider(
				sliderX, sliderY + 24, sliderWidth, () -> 0.0,
				() -> renderer.maxLogicalY(workingConfig, height), renderer.logicalY(workingConfig, height),
				value -> workingConfig.setY((int) Math.round(value)),
				value -> Text.translatable("option.opponenthud.y", Math.round(value))
		));
		scaleSlider = addDrawableChild(new ConfigSlider(
				sliderX, sliderY + 48, sliderWidth, () -> 0.5, () -> 2.0, workingConfig.scale(),
				value -> {
					workingConfig.setScale((float) value);
					renderer.clampPosition(workingConfig, width, height);
					syncPositionSliders();
				},
				value -> Text.translatable("option.opponenthud.scale", Math.round(value * 100.0))
		));
		retainSlider = addDrawableChild(new ConfigSlider(
				sliderX, sliderY + 72, sliderWidth, () -> 0.0, () -> 30.0, workingConfig.retainSeconds(),
				value -> workingConfig.setRetainSeconds((float) Math.round(value)),
				value -> Text.translatable("option.opponenthud.retain_seconds", Math.round(value))
		));

		int buttonY = panelY + 125;
		int buttonWidth = Math.max(48, (sliderWidth - CONTROL_GAP * 2) / 3);
		addDrawableChild(ButtonWidget.builder(Text.translatable("button.opponenthud.reset"), button -> reset())
				.dimensions(sliderX, buttonY, buttonWidth, ButtonWidget.DEFAULT_HEIGHT).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("gui.cancel"), button -> close())
				.dimensions(sliderX + buttonWidth + CONTROL_GAP, buttonY, buttonWidth, ButtonWidget.DEFAULT_HEIGHT).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> saveAndClose())
				.dimensions(sliderX + (buttonWidth + CONTROL_GAP) * 2, buttonY, buttonWidth, ButtonWidget.DEFAULT_HEIGHT).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		renderer.renderPreview(context, workingConfig);
		context.fill(panelX, panelY, panelX + panelWidth, panelY + CONTROL_PANEL_HEIGHT, 0xE512171C);
		drawOutline(context, panelX, panelY, panelWidth, CONTROL_PANEL_HEIGHT, 0xFF596873);
		context.drawCenteredTextWithShadow(textRenderer, title, panelX + panelWidth / 2, panelY + 9, 0xFFF5F7F8);
		super.render(context, mouseX, mouseY, delta);
		if (isPreviewHovered(mouseX, mouseY) && !isInsideControlPanel(mouseX, mouseY)) {
			context.setCursor(StandardCursors.RESIZE_ALL);
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubleClick) {
		if (click.button() == 0 && isPreviewHovered(click.x(), click.y()) && !isInsideControlPanel(click.x(), click.y())) {
			draggingPreview = true;
			dragOffsetX = click.x() - renderer.renderedX(workingConfig, width);
			dragOffsetY = click.y() - renderer.renderedY(workingConfig, height);
			return true;
		}
		return super.mouseClicked(click, doubleClick);
	}

	@Override
	public boolean mouseDragged(Click click, double deltaX, double deltaY) {
		if (draggingPreview && click.button() == 0) {
			float scale = workingConfig.scale();
			workingConfig.setX((int) Math.round((click.x() - dragOffsetX) / scale));
			workingConfig.setY((int) Math.round((click.y() - dragOffsetY) / scale));
			renderer.clampPosition(workingConfig, width, height);
			syncPositionSliders();
			return true;
		}
		return super.mouseDragged(click, deltaX, deltaY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		if (draggingPreview && click.button() == 0) {
			draggingPreview = false;
			return true;
		}
		return super.mouseReleased(click);
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private void saveAndClose() {
		savedConfig.applyFrom(workingConfig);
		savedConfig.save();
		client.setScreen(parent);
	}

	private void reset() {
		workingConfig.reset();
		renderer.clampPosition(workingConfig, width, height);
		syncAllSliders();
	}

	private void syncAllSliders() {
		syncPositionSliders();
		scaleSlider.sync(workingConfig.scale());
		retainSlider.sync(workingConfig.retainSeconds());
	}

	private void syncPositionSliders() {
		if (xSlider != null) {
			xSlider.sync(renderer.logicalX(workingConfig, width));
		}
		if (ySlider != null) {
			ySlider.sync(renderer.logicalY(workingConfig, height));
		}
	}

	private boolean isPreviewHovered(double mouseX, double mouseY) {
		int previewX = renderer.renderedX(workingConfig, width);
		int previewY = renderer.renderedY(workingConfig, height);
		return mouseX >= previewX && mouseX < previewX + renderer.renderedWidth(workingConfig)
				&& mouseY >= previewY && mouseY < previewY + renderer.renderedHeight(workingConfig);
	}

	private boolean isInsideControlPanel(double mouseX, double mouseY) {
		return mouseX >= panelX && mouseX < panelX + panelWidth
				&& mouseY >= panelY && mouseY < panelY + CONTROL_PANEL_HEIGHT;
	}

	private static void drawOutline(DrawContext context, int x, int y, int width, int height, int color) {
		context.fill(x, y, x + width, y + 1, color);
		context.fill(x, y + height - 1, x + width, y + height, color);
		context.fill(x, y, x + 1, y + height, color);
		context.fill(x + width - 1, y, x + width, y + height, color);
	}
}
