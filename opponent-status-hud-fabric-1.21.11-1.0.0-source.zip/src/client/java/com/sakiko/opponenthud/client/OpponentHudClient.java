package com.sakiko.opponenthud.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class OpponentHudClient implements ClientModInitializer {
	public static final String MOD_ID = "opponenthud";
	private static final KeyBinding.Category KEY_CATEGORY = KeyBinding.Category.create(id("main"));
	private static final KeyBinding TOGGLE_KEY = new KeyBinding(
			"key.opponenthud.toggle",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_H,
			KEY_CATEGORY
	);
	private static final KeyBinding CONFIG_KEY = new KeyBinding(
			"key.opponenthud.configure",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_O,
			KEY_CATEGORY
	);
	private static HudConfig config;
	private static TargetTracker targetTracker;
	private static OpponentHudRenderer renderer;

	@Override
	public void onInitializeClient() {
		config = HudConfig.load();
		targetTracker = new TargetTracker(config);
		renderer = new OpponentHudRenderer(targetTracker, config);

		KeyBindingHelper.registerKeyBinding(TOGGLE_KEY);
		KeyBindingHelper.registerKeyBinding(CONFIG_KEY);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (CONFIG_KEY.wasPressed()) {
				client.setScreen(createConfigScreen(client.currentScreen));
			}

			while (TOGGLE_KEY.wasPressed()) {
				targetTracker.toggle();
				if (client.player != null) {
					String key = targetTracker.isEnabled()
							? "message.opponenthud.enabled"
							: "message.opponenthud.disabled";
					client.player.sendMessage(Text.translatable(key), true);
				}
			}
			targetTracker.tick(client);
		});

		AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (world == MinecraftClient.getInstance().world
					&& TargetTracker.isValidTarget(entity, MinecraftClient.getInstance())) {
				targetTracker.focus((LivingEntity) entity);
			}
			return ActionResult.PASS;
		});

		HudElementRegistry.addLast(id("target_status"), renderer);
	}

	public static Screen createConfigScreen(Screen parent) {
		if (config == null || targetTracker == null || renderer == null) {
			throw new IllegalStateException("Opponent Status HUD is not initialized");
		}
		return new OpponentHudConfigScreen(parent, config, renderer);
	}

	public static void onProjectileHit(ProjectileEntity projectile, Entity hitEntity) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (targetTracker == null || client.world == null || client.player == null) {
			return;
		}

		if (projectile.getEntityWorld() == client.world && projectile.getOwner() == client.player
				&& TargetTracker.isValidTarget(hitEntity, client)) {
			targetTracker.focus((LivingEntity) hitEntity);
		}
	}

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}
}
