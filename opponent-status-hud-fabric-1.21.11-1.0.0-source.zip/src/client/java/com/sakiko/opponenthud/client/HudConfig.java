package com.sakiko.opponenthud.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

final class HudConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Logger LOGGER = LoggerFactory.getLogger(OpponentHudClient.MOD_ID);
	private static final String FILE_NAME = "opponenthud.json";

	private int x = 16;
	private int y = -1;
	private float scale = 1.0F;
	private int targetRetainTicks = 60;

	static HudConfig load() {
		Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
		if (Files.exists(path)) {
			try {
				HudConfig config = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), HudConfig.class);
				if (config != null) {
					config.sanitize();
					return config;
				}
			} catch (RuntimeException | IOException exception) {
				LOGGER.warn("Could not read {}; using defaults", path, exception);
			}
		}

		HudConfig config = new HudConfig();
		config.save();
		return config;
	}

	HudConfig copy() {
		HudConfig copy = new HudConfig();
		copy.applyFrom(this);
		return copy;
	}

	void applyFrom(HudConfig source) {
		x = source.x;
		y = source.y;
		scale = source.scale;
		targetRetainTicks = source.targetRetainTicks;
		sanitize();
	}

	void reset() {
		applyFrom(new HudConfig());
	}

	int x() {
		return x;
	}

	int y() {
		return y;
	}

	float scale() {
		return scale;
	}

	int retainTicks() {
		return targetRetainTicks;
	}

	float retainSeconds() {
		return targetRetainTicks / 20.0F;
	}

	void setX(int x) {
		this.x = Math.max(0, x);
	}

	void setY(int y) {
		this.y = Math.max(-1, y);
	}

	void setScale(float scale) {
		this.scale = MathHelper.clamp(scale, 0.5F, 2.0F);
	}

	void setRetainSeconds(float seconds) {
		targetRetainTicks = MathHelper.clamp(Math.round(seconds * 20.0F), 0, 20 * 30);
	}

	private void sanitize() {
		x = Math.max(0, x);
		y = Math.max(-1, y);
		scale = MathHelper.clamp(scale, 0.5F, 2.0F);
		targetRetainTicks = MathHelper.clamp(targetRetainTicks, 0, 20 * 30);
	}

	void save() {
		Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
		try {
			Files.createDirectories(path.getParent());
			Files.writeString(path, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException exception) {
			LOGGER.warn("Could not save config {}", path, exception);
		}
	}
}
