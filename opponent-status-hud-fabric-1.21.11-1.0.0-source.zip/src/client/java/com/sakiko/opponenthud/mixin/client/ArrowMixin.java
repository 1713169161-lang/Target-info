package com.sakiko.opponenthud.mixin.client;

import com.sakiko.opponenthud.client.OpponentHudClient;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PersistentProjectileEntity.class)
abstract class ArrowMixin {
	@Inject(method = "onEntityHit", at = @At("HEAD"))
	private void opponenthud$trackEntityHit(EntityHitResult hitResult, CallbackInfo callbackInfo) {
		OpponentHudClient.onProjectileHit((PersistentProjectileEntity) (Object) this, hitResult.getEntity());
	}
}
