package com.sakiko.opponenthud.mixin.client;

import com.sakiko.opponenthud.client.OpponentHudClient;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ProjectileEntity.class)
abstract class ProjectileMixin {
	@Inject(method = "onEntityHit", at = @At("HEAD"))
	private void opponenthud$trackEntityHit(EntityHitResult hitResult, CallbackInfo callbackInfo) {
		OpponentHudClient.onProjectileHit((ProjectileEntity) (Object) this, hitResult.getEntity());
	}
}
