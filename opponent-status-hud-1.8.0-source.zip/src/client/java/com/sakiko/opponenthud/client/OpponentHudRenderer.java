package com.sakiko.opponenthud.client;

import java.util.Locale;
import java.util.UUID;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.PlayerFaceExtractor;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jspecify.annotations.Nullable;

final class OpponentHudRenderer implements HudElement {
	static final int PANEL_WIDTH = 230;
	static final int PANEL_HEIGHT = 62;

	private static final int HEAD_SIZE = 38;
	private static final int BAR_WIDTH = 168;
	private static final int HEAD_BACKGROUND = 0xFF0A0D10;
	private static final int HEAD_BORDER = 0xFF4A5863;
	private static final int TEXT = 0xFFF5F7F8;
	private static final int MUTED_TEXT = 0xFFB8C3C9;
	private static final int HEALTH = 0xFF18C7D9;
	private static final int HEALTH_MEDIUM = 0xFFFFB300;
	private static final int HEALTH_LOW = 0xFFEF5350;
	private static final int ABSORPTION = 0xFFFFC43D;

	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD,
			EquipmentSlot.CHEST,
			EquipmentSlot.LEGS,
			EquipmentSlot.FEET
	};

	private final TargetTracker targetTracker;
	private final HudConfig config;
	private @Nullable HudData lastRenderedData;
	private @Nullable UUID smoothedTargetId;
	private float visibility;
	private float displayedHealth;

	OpponentHudRenderer(TargetTracker targetTracker, HudConfig config) {
		this.targetTracker = targetTracker;
		this.config = config;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		Minecraft client = Minecraft.getInstance();
		LivingEntity target = targetTracker.getTarget();
		boolean shouldShow = target != null && !client.gui.hud.isHidden() && client.player != null;
		float delta = Mth.clamp(deltaTracker.getRealtimeDeltaTicks(), 0.0F, 5.0F);

		if (shouldShow) {
			lastRenderedData = smoothHealth(target.getUUID(), HudData.fromEntity(target), delta);
		}

		if (lastRenderedData == null) {
			return;
		}

		float response = shouldShow ? 0.32F : 0.24F;
		float progress = 1.0F - (float) Math.exp(-response * delta);
		visibility = Mth.lerp(progress, visibility, shouldShow ? 1.0F : 0.0F);
		if (visibility <= 0.01F) {
			visibility = 0.0F;
			if (!shouldShow) {
				lastRenderedData = null;
			}
			return;
		}

		renderConfigured(graphics, lastRenderedData, config, visibility);
	}

	void renderPreview(GuiGraphicsExtractor graphics, HudConfig previewConfig) {
		Minecraft client = Minecraft.getInstance();
		LivingEntity target = targetTracker.getTarget();
		if (target == null) {
			target = client.player;
		}

		HudData data = target == null ? HudData.sample() : HudData.fromEntity(target);
		renderConfigured(graphics, data, previewConfig, 1.0F);
	}

	void clampPosition(HudConfig targetConfig, int screenWidth, int screenHeight) {
		targetConfig.setX(Mth.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth)));
		if (targetConfig.y() >= 0) {
			targetConfig.setY(Mth.clamp(targetConfig.y(), 0, maxLogicalY(targetConfig, screenHeight)));
		}
	}

	int logicalX(HudConfig targetConfig, int screenWidth) {
		return Mth.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth));
	}

	int logicalY(HudConfig targetConfig, int screenHeight) {
		int y = targetConfig.y() < 0 ? maxLogicalY(targetConfig, screenHeight) / 2 : targetConfig.y();
		return Mth.clamp(y, 0, maxLogicalY(targetConfig, screenHeight));
	}

	int maxLogicalX(HudConfig targetConfig, int screenWidth) {
		return Math.max(0, (int) (screenWidth / targetConfig.scale()) - PANEL_WIDTH);
	}

	int maxLogicalY(HudConfig targetConfig, int screenHeight) {
		return Math.max(0, (int) (screenHeight / targetConfig.scale()) - PANEL_HEIGHT);
	}

	int renderedX(HudConfig targetConfig, int screenWidth) {
		return Math.round(logicalX(targetConfig, screenWidth) * targetConfig.scale());
	}

	int renderedY(HudConfig targetConfig, int screenHeight) {
		return Math.round(logicalY(targetConfig, screenHeight) * targetConfig.scale());
	}

	int renderedWidth(HudConfig targetConfig) {
		return Math.round(PANEL_WIDTH * targetConfig.scale());
	}

	int renderedHeight(HudConfig targetConfig) {
		return Math.round(PANEL_HEIGHT * targetConfig.scale());
	}

	private static void renderConfigured(GuiGraphicsExtractor graphics, HudData data, HudConfig targetConfig, float visibility) {
		float scale = targetConfig.scale();
		int scaledWidth = Math.max(PANEL_WIDTH, (int) (graphics.guiWidth() / scale));
		int scaledHeight = Math.max(PANEL_HEIGHT, (int) (graphics.guiHeight() / scale));
		int x = Mth.clamp(targetConfig.x(), 0, scaledWidth - PANEL_WIDTH);
		int requestedY = targetConfig.y() < 0 ? scaledHeight / 2 - PANEL_HEIGHT / 2 : targetConfig.y();
		int y = Mth.clamp(requestedY, 0, scaledHeight - PANEL_HEIGHT);
		Font font = Minecraft.getInstance().font;

		graphics.pose().pushMatrix();
		graphics.pose().scale(scale);
		float easedVisibility = easeOutCubic(visibility);
		float centerX = x + PANEL_WIDTH / 2.0F;
		float centerY = y + PANEL_HEIGHT / 2.0F;
		graphics.pose().translate(centerX - (1.0F - easedVisibility) * 12.0F, centerY);
		graphics.pose().scale(0.90F + easedVisibility * 0.10F);
		graphics.pose().translate(-centerX, -centerY);
		SimpleStyle style = SimpleStyle.of(visibility);
		drawHead(graphics, font, data, x + 8, y + 12, style);
		drawNameAndHealth(graphics, font, data.name(), data.health(), data.maxHealth(), data.absorption(), x + 55, y + 8, style);
		drawHealthBar(graphics, data.health(), data.maxHealth(), data.absorption(), x + 55, y + 23, style);
		drawEquipment(graphics, font, data.owner(), data.armor(), data.mainHand(), data.offHand(), x + 55, y + 38);
		graphics.pose().popMatrix();
	}

	private static void drawHead(GuiGraphicsExtractor graphics, Font font, HudData data, int x, int y, SimpleStyle style) {
		graphics.fill(x - 2, y - 2, x + HEAD_SIZE + 2, y + HEAD_SIZE + 2, style.headBackground());
		graphics.outline(x - 1, y - 1, HEAD_SIZE + 2, HEAD_SIZE + 2, style.headBorder());
		if (data.skin() != null) {
			PlayerFaceExtractor.extractRenderState(graphics, data.skin(), x, y, HEAD_SIZE);
			return;
		}

		graphics.fill(x + 3, y + 3, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, multiplyAlpha(0xFF18232B, style.contentAlpha()));
		graphics.fill(x + 3, y + HEAD_SIZE - 7, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, multiplyAlpha(data.entityAccent(), style.contentAlpha()));
		graphics.centeredText(font, entityInitial(data.name()), x + HEAD_SIZE / 2, y + 13, style.text());
	}

	private static void drawNameAndHealth(
			GuiGraphicsExtractor graphics,
			Font font,
			String targetName,
			float health,
			float maxHealth,
			float absorption,
			int x,
			int y,
			SimpleStyle style
	) {
		String healthText = absorption > 0.0F
				? formatHealth(health) + " +" + formatHealth(absorption)
				: formatHealth(health) + " / " + formatHealth(maxHealth);
		int right = x + BAR_WIDTH;
		int healthWidth = font.width(healthText);
		int availableNameWidth = Math.max(20, BAR_WIDTH - healthWidth - 8);
		String name = ellipsize(font, targetName, availableNameWidth);

		graphics.text(font, name, x, y, style.text(), true);
		graphics.text(font, healthText, right - healthWidth, y, style.mutedText(), false);
	}

	private static void drawHealthBar(GuiGraphicsExtractor graphics, float health, float maxHealth, float absorption, int x, int y, SimpleStyle style) {
		float safeHealth = Math.max(0.0F, health);
		float safeMaxHealth = Math.max(1.0F, maxHealth);
		float safeAbsorption = Math.max(0.0F, absorption);
		float scaleMax = safeMaxHealth + safeAbsorption;
		int healthWidth = Mth.clamp(Math.round(BAR_WIDTH * safeHealth / scaleMax), 0, BAR_WIDTH);
		int absorptionWidth = Mth.clamp(Math.round(BAR_WIDTH * safeAbsorption / scaleMax), 0, BAR_WIDTH - healthWidth);
		float healthRatio = safeHealth / safeMaxHealth;
		int healthColor = healthRatio <= 0.25F ? HEALTH_LOW : healthRatio <= 0.5F ? HEALTH_MEDIUM : HEALTH;

		if (healthWidth > 0) {
			graphics.fill(x, y, x + healthWidth, y + 7, multiplyAlpha(healthColor, style.contentAlpha()));
		}
		if (absorptionWidth > 0) {
			graphics.fill(x + healthWidth, y, x + healthWidth + absorptionWidth, y + 7, multiplyAlpha(ABSORPTION, style.contentAlpha()));
		}
	}

	private static void drawEquipment(
			GuiGraphicsExtractor graphics,
			Font font,
			@Nullable LivingEntity owner,
			ItemStack[] armor,
			ItemStack mainHand,
			ItemStack offHand,
			int x,
			int y
	) {
		int itemIndex = 1;
		for (int index = 0; index < armor.length; index++) {
			int slotX = x + index * 22;
			drawItem(graphics, font, owner, armor[index], slotX, y, itemIndex++);
		}
		drawItem(graphics, font, owner, mainHand, x + armor.length * 22, y, itemIndex++);
		drawItem(graphics, font, owner, offHand, x + (armor.length + 1) * 22, y, itemIndex);
	}

	private static void drawItem(GuiGraphicsExtractor graphics, Font font, @Nullable LivingEntity owner, ItemStack stack, int x, int y, int itemIndex) {
		if (stack.isEmpty()) {
			return;
		}

		if (owner == null) {
			graphics.item(stack, x, y, itemIndex);
		} else {
			graphics.item(owner, stack, x, y, itemIndex);
		}
		graphics.itemDecorations(font, stack, x, y);
	}

	private HudData smoothHealth(UUID targetId, HudData data, float delta) {
		if (!targetId.equals(smoothedTargetId)) {
			smoothedTargetId = targetId;
			displayedHealth = data.health();
		} else if (data.health() < displayedHealth) {
			float progress = 1.0F - (float) Math.exp(-0.24F * delta);
			displayedHealth = Mth.lerp(progress, displayedHealth, data.health());
		} else {
			displayedHealth = data.health();
		}

		return data.withHealth(displayedHealth);
	}

	private record SimpleStyle(
			int headBackground,
			int headBorder,
			int text,
			int mutedText,
			float contentAlpha
	) {
		private static SimpleStyle of(float visibility) {
			float alpha = Mth.clamp(visibility, 0.0F, 1.0F);
			return new SimpleStyle(
					multiplyAlpha(HEAD_BACKGROUND, alpha),
					multiplyAlpha(HEAD_BORDER, alpha),
					multiplyAlpha(TEXT, alpha),
					multiplyAlpha(MUTED_TEXT, alpha),
					alpha
			);
		}
	}

	private static float easeOutCubic(float value) {
		float inverse = 1.0F - Mth.clamp(value, 0.0F, 1.0F);
		return 1.0F - inverse * inverse * inverse;
	}

	private static int multiplyAlpha(int color, float amount) {
		int alpha = Math.round((color >>> 24) * Mth.clamp(amount, 0.0F, 1.0F));
		return alpha << 24 | color & 0x00FFFFFF;
	}

	private static String ellipsize(Font font, String text, int maxWidth) {
		if (font.width(text) <= maxWidth) {
			return text;
		}

		String suffix = "...";
		return font.plainSubstrByWidth(text, Math.max(0, maxWidth - font.width(suffix))) + suffix;
	}

	private static String formatHealth(float value) {
		float rounded = Math.round(value * 10.0F) / 10.0F;
		if (rounded == (int) rounded) {
			return Integer.toString((int) rounded);
		}
		return Float.toString(rounded);
	}

	private static String entityInitial(String name) {
		return name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
	}

	private static int entityAccent(LivingEntity entity) {
		int hash = entity.getType().getDescriptionId().hashCode();
		return 0xFF000000 | 0x60 << 16 | ((hash >>> 8) & 0x7F) << 8 | (0x80 | hash & 0x7F);
	}

	private record HudData(
			@Nullable LivingEntity owner,
			String name,
			@Nullable PlayerSkin skin,
			int entityAccent,
			float health,
			float maxHealth,
			float absorption,
			ItemStack[] armor,
			ItemStack mainHand,
			ItemStack offHand
	) {
		private HudData withHealth(float health) {
			return new HudData(owner, name, skin, entityAccent, health, maxHealth, absorption, armor, mainHand, offHand);
		}

		private static HudData fromEntity(LivingEntity entity) {
			ItemStack[] armor = new ItemStack[ARMOR_SLOTS.length];
			for (int index = 0; index < ARMOR_SLOTS.length; index++) {
				armor[index] = entity.getItemBySlot(ARMOR_SLOTS[index]);
			}

			PlayerSkin skin = null;
			if (entity instanceof AbstractClientPlayer player) {
				skin = player.getSkin();
			} else if (entity instanceof Player player) {
				skin = DefaultPlayerSkin.get(player.getUUID());
			}

			return new HudData(
					entity,
					entity.getName().getString(),
					skin,
					OpponentHudRenderer.entityAccent(entity),
					Math.max(0.0F, entity.getHealth()),
					Math.max(1.0F, entity.getMaxHealth()),
					Math.max(0.0F, entity.getAbsorptionAmount()),
					armor,
					entity.getMainHandItem(),
					entity.getOffhandItem()
			);
		}

		private static HudData sample() {
			return new HudData(
					null,
					"Player",
					DefaultPlayerSkin.getDefaultSkin(),
					0xFF18C7D9,
					17.0F,
					20.0F,
					2.0F,
					new ItemStack[]{
						damaged(Items.DIAMOND_HELMET, 0.15F),
						damaged(Items.DIAMOND_CHESTPLATE, 0.35F),
						damaged(Items.DIAMOND_LEGGINGS, 0.55F),
						damaged(Items.DIAMOND_BOOTS, 0.75F)
					},
					damaged(Items.DIAMOND_SWORD, 0.2F),
					damaged(Items.SHIELD, 0.35F)
			);
		}

		private static ItemStack damaged(net.minecraft.world.item.Item item, float damageRatio) {
			ItemStack stack = new ItemStack(item);
			stack.setDamageValue(Math.round(stack.getMaxDamage() * damageRatio));
			return stack;
		}
	}
}
