package com.sakiko.opponenthud.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import org.lwjgl.glfw.GLFW;

public final class OpponentHudClient implements ClientModInitializer {
	public static final String MOD_ID = "opponenthud";
	private static final KeyMapping.Category KEY_CATEGORY = KeyMapping.Category.register(id("main"));
	private static final KeyMapping TOGGLE_KEY = new KeyMapping(
			"key.opponenthud.toggle",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_H,
			KEY_CATEGORY
	);
	private static final KeyMapping CONFIG_KEY = new KeyMapping(
			"key.opponenthud.configure",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_O,
			KEY_CATEGORY
	);
	private static HudConfig config;
	private static TargetTracker targetTracker;
	private static OpponentHudRenderer renderer;

	@Override
	public void onInitializeClient() {
		config = HudConfig.load();
		targetTracker = new TargetTracker(config);
		renderer = new OpponentHudRenderer(targetTracker, config);

		KeyMappingHelper.registerKeyMapping(TOGGLE_KEY);
		KeyMappingHelper.registerKeyMapping(CONFIG_KEY);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (CONFIG_KEY.consumeClick()) {
				client.gui.setScreen(createConfigScreen(client.gui.screen()));
			}

			while (TOGGLE_KEY.consumeClick()) {
				targetTracker.toggle();
				if (client.player != null) {
					String key = targetTracker.isEnabled()
							? "message.opponenthud.enabled"
							: "message.opponenthud.disabled";
					client.player.sendOverlayMessage(Component.translatable(key));
				}
			}
			targetTracker.tick(client);
		});

		AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
			if (level.isClientSide() && TargetTracker.isValidTarget(entity, Minecraft.getInstance())) {
				targetTracker.focus((LivingEntity) entity);
			}
			return InteractionResult.PASS;
		});

		HudElementRegistry.addLast(id("target_status"), renderer);
	}

	public static Screen createConfigScreen(Screen parent) {
		if (config == null || targetTracker == null || renderer == null) {
			throw new IllegalStateException("Opponent Status HUD is not initialized");
		}
		return new OpponentHudConfigScreen(parent, config, renderer);
	}

	public static void onProjectileHit(Projectile projectile, Entity hitEntity) {
		Minecraft client = Minecraft.getInstance();
		if (targetTracker == null || client.level == null || client.player == null) {
			return;
		}

		if (projectile.level() == client.level && projectile.getOwner() == client.player
				&& TargetTracker.isValidTarget(hitEntity, client)) {
			targetTracker.focus((LivingEntity) hitEntity);
		}
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
