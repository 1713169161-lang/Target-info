package com.sakiko.opponenthud.client;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

final class ConfigSlider extends AbstractSliderButton {
	private final DoubleSupplier minimum;
	private final DoubleSupplier maximum;
	private final DoubleConsumer setter;
	private final DoubleFunction<Component> messageFactory;

	ConfigSlider(
			int x,
			int y,
			int width,
			DoubleSupplier minimum,
			DoubleSupplier maximum,
			double initialValue,
			DoubleConsumer setter,
			DoubleFunction<Component> messageFactory
	) {
		super(x, y, width, DEFAULT_HEIGHT, Component.empty(), normalize(initialValue, minimum.getAsDouble(), maximum.getAsDouble()));
		this.minimum = minimum;
		this.maximum = maximum;
		this.setter = setter;
		this.messageFactory = messageFactory;
		updateMessage();
	}

	@Override
	protected void updateMessage() {
		setMessage(messageFactory.apply(mappedValue()));
	}

	@Override
	protected void applyValue() {
		setter.accept(mappedValue());
	}

	void sync(double currentValue) {
		value = normalize(currentValue, minimum.getAsDouble(), maximum.getAsDouble());
		updateMessage();
	}

	private double mappedValue() {
		double min = minimum.getAsDouble();
		double max = maximum.getAsDouble();
		return min + value * Math.max(0.0, max - min);
	}

	private static double normalize(double value, double min, double max) {
		if (max <= min) {
			return 0.0;
		}
		return Mth.clamp((value - min) / (max - min), 0.0, 1.0);
	}
}
