package com.sakiko.opponenthud.client;

import com.mojang.blaze3d.platform.cursor.CursorTypes;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

final class OpponentHudConfigScreen extends Screen {
	private static final int CONTROL_PANEL_WIDTH = 268;
	private static final int CONTROL_PANEL_HEIGHT = 157;
	private static final int CONTROL_MARGIN = 12;
	private static final int CONTROL_GAP = 5;

	private final Screen parent;
	private final HudConfig savedConfig;
	private final HudConfig workingConfig;
	private final OpponentHudRenderer renderer;

	private ConfigSlider xSlider;
	private ConfigSlider ySlider;
	private ConfigSlider scaleSlider;
	private ConfigSlider retainSlider;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private boolean draggingPreview;
	private double dragOffsetX;
	private double dragOffsetY;

	OpponentHudConfigScreen(Screen parent, HudConfig config, OpponentHudRenderer renderer) {
		super(Component.translatable("screen.opponenthud.config"));
		this.parent = parent;
		this.savedConfig = config;
		this.workingConfig = config.copy();
		this.renderer = renderer;
	}

	@Override
	protected void init() {
		panelWidth = Math.min(CONTROL_PANEL_WIDTH, width - CONTROL_MARGIN * 2);
		panelX = Math.max(CONTROL_MARGIN, width - panelWidth - CONTROL_MARGIN);
		panelY = CONTROL_MARGIN;
		int sliderX = panelX + 10;
		int sliderWidth = panelWidth - 20;
		int sliderY = panelY + 27;

		xSlider = addRenderableWidget(new ConfigSlider(
				sliderX,
				sliderY,
				sliderWidth,
				() -> 0.0,
				() -> renderer.maxLogicalX(workingConfig, width),
				renderer.logicalX(workingConfig, width),
				value -> workingConfig.setX((int) Math.round(value)),
				value -> Component.translatable("option.opponenthud.x", Math.round(value))
		));

		ySlider = addRenderableWidget(new ConfigSlider(
				sliderX,
				sliderY + 24,
				sliderWidth,
				() -> 0.0,
				() -> renderer.maxLogicalY(workingConfig, height),
				renderer.logicalY(workingConfig, height),
				value -> workingConfig.setY((int) Math.round(value)),
				value -> Component.translatable("option.opponenthud.y", Math.round(value))
		));

		scaleSlider = addRenderableWidget(new ConfigSlider(
				sliderX,
				sliderY + 48,
				sliderWidth,
				() -> 0.5,
				() -> 2.0,
				workingConfig.scale(),
				value -> {
					workingConfig.setScale((float) value);
					renderer.clampPosition(workingConfig, width, height);
					syncPositionSliders();
				},
				value -> Component.translatable("option.opponenthud.scale", Math.round(value * 100.0))
		));

		retainSlider = addRenderableWidget(new ConfigSlider(
				sliderX,
				sliderY + 72,
				sliderWidth,
				() -> 0.0,
				() -> 30.0,
				workingConfig.retainSeconds(),
				value -> workingConfig.setRetainSeconds((float) Math.round(value)),
				value -> Component.translatable("option.opponenthud.retain_seconds", Math.round(value))
		));

		int buttonY = panelY + 125;
		int buttonWidth = Math.max(48, (sliderWidth - CONTROL_GAP * 2) / 3);
		addRenderableWidget(Button.builder(Component.translatable("button.opponenthud.reset"), button -> reset()).bounds(
				sliderX, buttonY, buttonWidth, Button.DEFAULT_HEIGHT
		).build());
		addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, button -> onClose()).bounds(
				sliderX + buttonWidth + CONTROL_GAP, buttonY, buttonWidth, Button.DEFAULT_HEIGHT
		).build());
		addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, button -> saveAndClose()).bounds(
				sliderX + (buttonWidth + CONTROL_GAP) * 2, buttonY, buttonWidth, Button.DEFAULT_HEIGHT
		).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
		renderer.renderPreview(graphics, workingConfig);
		graphics.nextStratum();
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + CONTROL_PANEL_HEIGHT, 0xE512171C);
		graphics.outline(panelX, panelY, panelWidth, CONTROL_PANEL_HEIGHT, 0xFF596873);
		graphics.centeredText(font, title, panelX + panelWidth / 2, panelY + 9, 0xFFF5F7F8);
		super.extractRenderState(graphics, mouseX, mouseY, tickProgress);

		if (isPreviewHovered(mouseX, mouseY) && !isInsideControlPanel(mouseX, mouseY)) {
			graphics.requestCursor(CursorTypes.RESIZE_ALL);
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 0 && isPreviewHovered(event.x(), event.y()) && !isInsideControlPanel(event.x(), event.y())) {
			draggingPreview = true;
			dragOffsetX = event.x() - renderer.renderedX(workingConfig, width);
			dragOffsetY = event.y() - renderer.renderedY(workingConfig, height);
			return true;
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
		if (draggingPreview && event.button() == 0) {
			float scale = workingConfig.scale();
			workingConfig.setX((int) Math.round((event.x() - dragOffsetX) / scale));
			workingConfig.setY((int) Math.round((event.y() - dragOffsetY) / scale));
			renderer.clampPosition(workingConfig, width, height);
			syncPositionSliders();
			return true;
		}
		return super.mouseDragged(event, deltaX, deltaY);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (draggingPreview && event.button() == 0) {
			draggingPreview = false;
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public void onClose() {
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isInGameUi() {
		return minecraft.level != null;
	}

	private void saveAndClose() {
		savedConfig.applyFrom(workingConfig);
		savedConfig.save();
		minecraft.gui.setScreen(parent);
	}

	private void reset() {
		workingConfig.reset();
		renderer.clampPosition(workingConfig, width, height);
		syncAllSliders();
	}

	private void syncAllSliders() {
		syncPositionSliders();
		scaleSlider.sync(workingConfig.scale());
		retainSlider.sync(workingConfig.retainSeconds());
	}

	private void syncPositionSliders() {
		if (xSlider != null) {
			xSlider.sync(renderer.logicalX(workingConfig, width));
		}
		if (ySlider != null) {
			ySlider.sync(renderer.logicalY(workingConfig, height));
		}
	}

	private boolean isPreviewHovered(double mouseX, double mouseY) {
		int previewX = renderer.renderedX(workingConfig, width);
		int previewY = renderer.renderedY(workingConfig, height);
		return mouseX >= previewX
				&& mouseX < previewX + renderer.renderedWidth(workingConfig)
				&& mouseY >= previewY
				&& mouseY < previewY + renderer.renderedHeight(workingConfig);
	}

	private boolean isInsideControlPanel(double mouseX, double mouseY) {
		return mouseX >= panelX
				&& mouseX < panelX + panelWidth
				&& mouseY >= panelY
				&& mouseY < panelY + CONTROL_PANEL_HEIGHT;
	}
}
