package com.sakiko.opponenthud.mixin.client;

import com.sakiko.opponenthud.client.OpponentHudClient;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractArrow.class)
abstract class ArrowMixin {
	@Inject(method = "onHitEntity", at = @At("HEAD"))
	private void opponenthud$trackEntityHit(EntityHitResult hitResult, CallbackInfo callbackInfo) {
		OpponentHudClient.onProjectileHit((AbstractArrow) (Object) this, hitResult.getEntity());
	}
}
