package com.sakiko.opponenthud.mixin.client;

import com.sakiko.opponenthud.client.OpponentHudClient;
import net.minecraft.world.entity.projectile.arrow.ThrownTrident;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ThrownTrident.class)
abstract class ThrownTridentMixin {
	@Inject(method = "onHitEntity", at = @At("HEAD"))
	private void opponenthud$trackEntityHit(EntityHitResult hitResult, CallbackInfo callbackInfo) {
		OpponentHudClient.onProjectileHit((ThrownTrident) (Object) this, hitResult.getEntity());
	}
}
