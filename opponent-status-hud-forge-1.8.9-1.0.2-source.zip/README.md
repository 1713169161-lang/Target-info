# Opponent Status HUD - Forge 1.8.9

Minecraft Forge 1.8.9 的纯客户端移植版，功能包括：

- 准星指向或攻击其他玩家时锁定目标
- 可设置离开准星后的保留时间（0-30 秒，默认 3 秒）
- 玩家头像、名称、血量、盔甲和主手持有物
- 掉血时血条与数值平滑过渡
- 无外层背景的悬浮 HUD，保留入场和出场动画
- 按 `H` 开关 HUD，按 `O` 打开游戏内设置
- 直接键盘轮询备用路径，适应未正确派发 Forge 客户端 Tick 的第三方启动器环境

## 限制

Minecraft 1.8.9 原版没有副手/左手物品栏，因此这个版本无法可靠显示对方副手。若服务器使用双持 Mod，需要针对该 Mod 的网络同步接口单独适配。

Lunar 将 JAR 列在“外部”模组页面，只表示它已被识别，并不必然代表其 Forge 生命周期与事件总线都已执行。1.0.2 已绕过 Forge 的键位和客户端 Tick 事件，并使用标准 Minecraft 按钮绘制配置控件；若在游戏世界中按 `O` 仍毫无反应，说明该环境没有实际初始化此 Forge 模组，只能使用普通 Forge 1.8.9 实例运行。

## 环境

- Minecraft 1.8.9
- Forge 11.15.1.2318
- Java 8

## 安装

将 `opponent-status-hud-forge-1.8.9-1.0.2.jar` 放进 1.8.9 Forge 实例的 `mods` 文件夹。无需服务端安装。

## 构建

使用 Java 8 运行：

```bash
./gradlew build
```

构建产物位于 `build/libs/opponent-status-hud-forge-1.8.9-1.0.2.jar`。
