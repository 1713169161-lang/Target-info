package com.sakiko.opponenthud.forge189;

import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

final class ForgeHudConfigScreen extends GuiScreen {
	private static final int CONTROL_WIDTH = 220;
	private static final int CONTROL_HEIGHT = 164;
	private static final int MARGIN = 12;
	private static final int ROW_HEIGHT = 18;
	private static final int ROW_GAP = 4;
	private static final int SIDE_BUTTON_WIDTH = 20;
	private static final int BUTTON_GAP = 4;

	private static final int RESET = 0;
	private static final int CANCEL = 1;
	private static final int DONE = 2;
	private static final int TITLE = 3;
	private static final int X_DECREASE = 10;
	private static final int X_VALUE = 11;
	private static final int X_INCREASE = 12;
	private static final int Y_DECREASE = 13;
	private static final int Y_VALUE = 14;
	private static final int Y_INCREASE = 15;
	private static final int SCALE_DECREASE = 16;
	private static final int SCALE_VALUE = 17;
	private static final int SCALE_INCREASE = 18;
	private static final int RETAIN_DECREASE = 19;
	private static final int RETAIN_VALUE = 20;
	private static final int RETAIN_INCREASE = 21;

	private final GuiScreen parent;
	private final ForgeHudConfig savedConfig;
	private final ForgeHudConfig workingConfig;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private boolean draggingPreview;
	private double dragOffsetX;
	private double dragOffsetY;

	ForgeHudConfigScreen(GuiScreen parent, ForgeHudConfig config) {
		this.parent = parent;
		this.savedConfig = config;
		this.workingConfig = config.copy();
	}

	@Override
	public void initGui() {
		buttonList.clear();
		panelWidth = Math.min(CONTROL_WIDTH, Math.max(176, width * 45 / 100));
		panelWidth = Math.min(panelWidth, Math.max(120, width - MARGIN * 2));
		panelX = Math.max(MARGIN, width - panelWidth - MARGIN);
		panelY = MARGIN;
		int contentX = panelX + 10;
		int rowY = panelY + 30;

		GuiButton titleButton = new GuiButton(TITLE, contentX, panelY + 7, panelWidth - 20, 18, "Opponent Status HUD");
		titleButton.enabled = false;
		buttonList.add(titleButton);
		addAdjustmentRow(rowY, X_DECREASE, X_VALUE, X_INCREASE);
		addAdjustmentRow(rowY + (ROW_HEIGHT + ROW_GAP), Y_DECREASE, Y_VALUE, Y_INCREASE);
		addAdjustmentRow(rowY + (ROW_HEIGHT + ROW_GAP) * 2, SCALE_DECREASE, SCALE_VALUE, SCALE_INCREASE);
		addAdjustmentRow(rowY + (ROW_HEIGHT + ROW_GAP) * 3, RETAIN_DECREASE, RETAIN_VALUE, RETAIN_INCREASE);

		int buttonY = panelY + 133;
		int buttonWidth = Math.max(48, (panelWidth - 20 - 10) / 3);
		buttonList.add(new GuiButton(RESET, contentX, buttonY, buttonWidth, 20, "Reset"));
		buttonList.add(new GuiButton(CANCEL, contentX + buttonWidth + 5, buttonY, buttonWidth, 20, "Cancel"));
		buttonList.add(new GuiButton(DONE, contentX + (buttonWidth + 5) * 2, buttonY, buttonWidth, 20, "Done"));
		refreshButtonLabels();
	}

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		drawDefaultBackground();
		drawRect(panelX, panelY, panelX + panelWidth, panelY + CONTROL_HEIGHT, 0xE512171C);
		drawOutline(panelX, panelY, panelWidth, CONTROL_HEIGHT, 0xFF596873);
		OpponentHudForge.instance.renderPreview(workingConfig);
		super.drawScreen(mouseX, mouseY, partialTicks);
	}

	@Override
	protected void actionPerformed(GuiButton button) {
		if (button.id == RESET) {
			workingConfig.reset();
			clampPosition();
		} else if (button.id == CANCEL) {
			mc.displayGuiScreen(parent);
		} else if (button.id == DONE) {
			savedConfig.applyFrom(workingConfig);
			savedConfig.save();
			mc.displayGuiScreen(parent);
		} else if (button.id == X_DECREASE) {
			workingConfig.setX(workingConfig.x() - positionStep(maxX()));
			clampPosition();
		} else if (button.id == X_INCREASE) {
			workingConfig.setX(workingConfig.x() + positionStep(maxX()));
			clampPosition();
		} else if (button.id == Y_DECREASE) {
			workingConfig.setY(logicalY() - positionStep(maxY()));
			clampPosition();
		} else if (button.id == Y_INCREASE) {
			workingConfig.setY(logicalY() + positionStep(maxY()));
			clampPosition();
		} else if (button.id == SCALE_DECREASE) {
			workingConfig.setScale(roundScale(workingConfig.scale() - 0.1F));
			clampPosition();
		} else if (button.id == SCALE_INCREASE) {
			workingConfig.setScale(roundScale(workingConfig.scale() + 0.1F));
			clampPosition();
		} else if (button.id == RETAIN_DECREASE) {
			workingConfig.setRetainSeconds(workingConfig.retainSeconds() - 1.0F);
		} else if (button.id == RETAIN_INCREASE) {
			workingConfig.setRetainSeconds(workingConfig.retainSeconds() + 1.0F);
		}
		refreshButtonLabels();
	}

	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		if (mouseButton == 0 && isPreviewHovered(mouseX, mouseY) && !isInsideControlPanel(mouseX, mouseY)) {
			draggingPreview = true;
			dragOffsetX = mouseX - OpponentHudForge.instance.renderedX(workingConfig, scaledWidth());
			dragOffsetY = mouseY - OpponentHudForge.instance.renderedY(workingConfig, scaledHeight());
			return;
		}

		super.mouseClicked(mouseX, mouseY, mouseButton);
	}

	@Override
	protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
		if (draggingPreview && clickedMouseButton == 0) {
			float scale = workingConfig.scale();
			workingConfig.setX(Math.round((float) ((mouseX - dragOffsetX) / scale)));
			workingConfig.setY(Math.round((float) ((mouseY - dragOffsetY) / scale)));
			clampPosition();
			return;
		}

	}

	@Override
	protected void mouseReleased(int mouseX, int mouseY, int state) {
		if (state == 0) {
			draggingPreview = false;
		}
		super.mouseReleased(mouseX, mouseY, state);
	}

	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}

	private void addAdjustmentRow(int y, int decreaseId, int valueId, int increaseId) {
		int x = panelX + 10;
		int valueWidth = panelWidth - 20 - SIDE_BUTTON_WIDTH * 2 - BUTTON_GAP * 2;
		buttonList.add(new GuiButton(decreaseId, x, y, SIDE_BUTTON_WIDTH, ROW_HEIGHT, "<"));
		buttonList.add(new GuiButton(valueId, x + SIDE_BUTTON_WIDTH + BUTTON_GAP, y, valueWidth, ROW_HEIGHT, ""));
		buttonList.add(new GuiButton(increaseId, x + SIDE_BUTTON_WIDTH + BUTTON_GAP + valueWidth + BUTTON_GAP, y, SIDE_BUTTON_WIDTH, ROW_HEIGHT, ">"));
	}

	private void refreshButtonLabels() {
		setButtonLabel(X_VALUE, "Horizontal position: " + workingConfig.x());
		setButtonLabel(Y_VALUE, "Vertical position: " + logicalY());
		setButtonLabel(SCALE_VALUE, "UI size: " + Math.round(workingConfig.scale() * 100.0F) + "%");
		setButtonLabel(RETAIN_VALUE, "Target retention: " + Math.round(workingConfig.retainSeconds()) + " s");
	}

	private void setButtonLabel(int id, String label) {
		for (Object object : buttonList) {
			GuiButton button = (GuiButton) object;
			if (button.id == id) {
				button.displayString = label;
				return;
			}
		}
	}

	private boolean isPreviewHovered(int mouseX, int mouseY) {
		int x = OpponentHudForge.instance.renderedX(workingConfig, scaledWidth());
		int y = OpponentHudForge.instance.renderedY(workingConfig, scaledHeight());
		int width = Math.round(OpponentHudForge.HUD_WIDTH * workingConfig.scale());
		int height = Math.round(OpponentHudForge.HUD_HEIGHT * workingConfig.scale());
		return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
	}

	private boolean isInsideControlPanel(int mouseX, int mouseY) {
		return mouseX >= panelX && mouseX < panelX + panelWidth && mouseY >= panelY && mouseY < panelY + CONTROL_HEIGHT;
	}

	private int maxX() {
		return OpponentHudForge.instance.maxLogicalX(workingConfig, scaledWidth());
	}

	private int maxY() {
		return OpponentHudForge.instance.maxLogicalY(workingConfig, scaledHeight());
	}

	private int logicalY() {
		return OpponentHudForge.instance.logicalY(workingConfig, scaledHeight());
	}

	private void clampPosition() {
		OpponentHudForge.instance.clampPosition(workingConfig, scaledWidth(), scaledHeight());
	}

	private static int positionStep(int maximum) {
		return Math.max(1, Math.max(5, maximum / 20));
	}

	private static float roundScale(float value) {
		return Math.round(value * 10.0F) / 10.0F;
	}

	private int scaledWidth() {
		return new ScaledResolution(mc).getScaledWidth();
	}

	private int scaledHeight() {
		return new ScaledResolution(mc).getScaledHeight();
	}

	private static void drawOutline(int x, int y, int width, int height, int color) {
		drawRect(x, y, x + width, y + 1, color);
		drawRect(x, y + height - 1, x + width, y + height, color);
		drawRect(x, y, x + 1, y + height, color);
		drawRect(x + width - 1, y, x + width, y + height, color);
	}

}
