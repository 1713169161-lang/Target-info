package com.sakiko.opponenthud.forge189;

import java.util.UUID;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod(
		modid = OpponentHudForge.MOD_ID,
		name = OpponentHudForge.NAME,
		version = OpponentHudForge.VERSION,
		acceptedMinecraftVersions = "[1.8.9]",
		clientSideOnly = true
)
public final class OpponentHudForge {
	public static final String MOD_ID = "opponenthud";
	public static final String NAME = "Opponent Status HUD";
	public static final String VERSION = "1.0.2";
	static final int HUD_WIDTH = 230;
	static final int HUD_HEIGHT = 62;

	private static final int HEAD_SIZE = 38;
	private static final int BAR_WIDTH = 168;
	private static final int HEAD_BACKGROUND = 0xFF0A0D10;
	private static final int HEAD_BORDER = 0xFF4A5863;
	private static final int TEXT = 0xFFF5F7F8;
	private static final int MUTED_TEXT = 0xFFB8C3C9;
	private static final int HEALTH = 0xFF18C7D9;
	private static final int HEALTH_MEDIUM = 0xFFFFB300;
	private static final int HEALTH_LOW = 0xFFEF5350;
	private static final int ABSORPTION = 0xFFFFC43D;

	@Mod.Instance(MOD_ID)
	static OpponentHudForge instance;

	private final TargetTracker targetTracker = new TargetTracker();
	private ForgeHudConfig config;
	private KeyBinding toggleKey;
	private KeyBinding configureKey;
	private boolean enabled = true;
	private HudData lastRenderedData;
	private UUID smoothedTargetId;
	private float displayedHealth;
	private float visibility;
	private boolean fallbackToggleDown;
	private boolean fallbackConfigureDown;
	private int lastObservedGameTick = Integer.MIN_VALUE;

	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		config = ForgeHudConfig.load(event.getSuggestedConfigurationFile());
	}

	@Mod.EventHandler
	public void init(FMLInitializationEvent event) {
		toggleKey = new KeyBinding("key.opponenthud.toggle", Keyboard.KEY_H, "key.categories.opponenthud");
		configureKey = new KeyBinding("key.opponenthud.configure", Keyboard.KEY_O, "key.categories.opponenthud");
		ClientRegistry.registerKeyBinding(toggleKey);
		ClientRegistry.registerKeyBinding(configureKey);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@SubscribeEvent
	public void onAttack(AttackEntityEvent event) {
		if (config != null && event.entityPlayer.worldObj.isRemote && event.target instanceof EntityPlayer && event.target != event.entityPlayer) {
			targetTracker.focus((EntityPlayer) event.target, config.retainTicks());
		}
	}

	@SubscribeEvent
	public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
		Minecraft minecraft = Minecraft.getMinecraft();
		processInput(minecraft);
		updateHudState(minecraft);
		if (minecraft.currentScreen instanceof ForgeHudConfigScreen || minecraft.gameSettings.hideGUI) {
			return;
		}

		EntityPlayer target = enabled ? targetTracker.getTarget() : null;
		if (target != null) {
			lastRenderedData = smoothHealth(target.getUniqueID(), HudData.fromPlayer(target), 0.35F);
		}

		if (lastRenderedData != null && visibility > 0.01F) {
			renderHud(lastRenderedData, config, visibility);
		}
	}

	/*
	 * Runs from the overlay event so launchers that omit Forge's client-tick bus can
	 * still drive the HUD. Player ticks keep target retention independent of FPS.
	 */
	private void updateHudState(Minecraft minecraft) {
		if (config == null || minecraft.thePlayer == null || minecraft.theWorld == null) {
			lastObservedGameTick = Integer.MIN_VALUE;
			visibility = 0.0F;
			lastRenderedData = null;
			return;
		}

		int gameTick = minecraft.thePlayer.ticksExisted;
		if (gameTick == lastObservedGameTick) {
			return;
		}
		lastObservedGameTick = gameTick;

		targetTracker.tick(minecraft, config.retainTicks());
		boolean shouldShow = enabled && targetTracker.getTarget() != null && !minecraft.gameSettings.hideGUI;
		visibility = approach(visibility, shouldShow ? 1.0F : 0.0F, shouldShow ? 0.20F : 0.15F);
		if (!shouldShow && visibility <= 0.01F) {
			visibility = 0.0F;
			lastRenderedData = null;
		}
	}

	private void processInput(Minecraft minecraft) {
		boolean toggleDown = isKeyBindingDown(toggleKey);
		boolean configureDown = isKeyBindingDown(configureKey);

		if (minecraft.currentScreen == null) {
			if (toggleDown && !fallbackToggleDown) {
				enabled = !enabled;
				if (minecraft.thePlayer != null) {
					minecraft.thePlayer.addChatMessage(new ChatComponentText(
							enabled ? "Opponent Status HUD: enabled" : "Opponent Status HUD: disabled"
					));
				}
			}
			if (configureDown && !fallbackConfigureDown && config != null) {
				minecraft.displayGuiScreen(new ForgeHudConfigScreen(null, config));
			}
		}

		fallbackToggleDown = toggleDown;
		fallbackConfigureDown = configureDown;
	}

	private static boolean isKeyBindingDown(KeyBinding keyBinding) {
		if (keyBinding == null) {
			return false;
		}
		int keyCode = keyBinding.getKeyCode();
		if (keyCode > 0) {
			return Keyboard.isKeyDown(keyCode);
		}
		return keyCode < 0 && Mouse.isButtonDown(keyCode + 100);
	}

	void renderPreview(ForgeHudConfig previewConfig) {
		EntityPlayer target = targetTracker.getTarget();
		HudData data = target == null ? HudData.sample() : HudData.fromPlayer(target);
		renderHud(data, previewConfig, 1.0F);
	}

	int maxLogicalX(ForgeHudConfig targetConfig, int screenWidth) {
		return Math.max(0, (int) (screenWidth / targetConfig.scale()) - HUD_WIDTH);
	}

	int maxLogicalY(ForgeHudConfig targetConfig, int screenHeight) {
		return Math.max(0, (int) (screenHeight / targetConfig.scale()) - HUD_HEIGHT);
	}

	int logicalX(ForgeHudConfig targetConfig, int screenWidth) {
		return clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth));
	}

	int logicalY(ForgeHudConfig targetConfig, int screenHeight) {
		int y = targetConfig.y() < 0 ? maxLogicalY(targetConfig, screenHeight) / 2 : targetConfig.y();
		return clamp(y, 0, maxLogicalY(targetConfig, screenHeight));
	}

	int renderedX(ForgeHudConfig targetConfig, int screenWidth) {
		return Math.round(logicalX(targetConfig, screenWidth) * targetConfig.scale());
	}

	int renderedY(ForgeHudConfig targetConfig, int screenHeight) {
		return Math.round(logicalY(targetConfig, screenHeight) * targetConfig.scale());
	}

	void clampPosition(ForgeHudConfig targetConfig, int screenWidth, int screenHeight) {
		targetConfig.setX(clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth)));
		if (targetConfig.y() >= 0) {
			targetConfig.setY(clamp(targetConfig.y(), 0, maxLogicalY(targetConfig, screenHeight)));
		}
	}

	private void renderHud(HudData data, ForgeHudConfig targetConfig, float alpha) {
		Minecraft minecraft = Minecraft.getMinecraft();
		ScaledResolution resolution = new ScaledResolution(minecraft);
		float scale = targetConfig.scale();
		int x = logicalX(targetConfig, resolution.getScaledWidth());
		int y = logicalY(targetConfig, resolution.getScaledHeight());
		float eased = easeOutCubic(alpha);

		GlStateManager.pushMatrix();
		GlStateManager.scale(scale, scale, 1.0F);
		GlStateManager.translate(x + HUD_WIDTH / 2.0F - (1.0F - eased) * 12.0F, y + HUD_HEIGHT / 2.0F, 0.0F);
		GlStateManager.scale(0.90F + eased * 0.10F, 0.90F + eased * 0.10F, 1.0F);
		GlStateManager.translate(-(x + HUD_WIDTH / 2.0F), -(y + HUD_HEIGHT / 2.0F), 0.0F);

		FontRenderer font = minecraft.fontRendererObj;
		drawHead(minecraft, data.skin, x + 8, y + 12, alpha);
		drawNameAndHealth(font, data, x + 55, y + 8, alpha);
		drawHealthBar(data, x + 55, y + 23, alpha);
		drawEquipment(minecraft, font, data, x + 55, y + 38);
		GlStateManager.popMatrix();
	}

	private static void drawHead(Minecraft minecraft, ResourceLocation skin, int x, int y, float alpha) {
		Gui.drawRect(x - 2, y - 2, x + HEAD_SIZE + 2, y + HEAD_SIZE + 2, multiplyAlpha(HEAD_BACKGROUND, alpha));
		drawOutline(x - 1, y - 1, HEAD_SIZE + 2, HEAD_SIZE + 2, multiplyAlpha(HEAD_BORDER, alpha));
		minecraft.getTextureManager().bindTexture(skin);
		Gui.drawScaledCustomSizeModalRect(x, y, 8.0F, 8.0F, 8, 8, HEAD_SIZE, HEAD_SIZE, 64.0F, 64.0F);
		Gui.drawScaledCustomSizeModalRect(x, y, 40.0F, 8.0F, 8, 8, HEAD_SIZE, HEAD_SIZE, 64.0F, 64.0F);
	}

	private static void drawNameAndHealth(FontRenderer font, HudData data, int x, int y, float alpha) {
		String healthText = data.absorption > 0.0F
				? formatHealth(data.health) + " +" + formatHealth(data.absorption)
				: formatHealth(data.health) + " / " + formatHealth(data.maxHealth);
		int healthWidth = font.getStringWidth(healthText);
		int availableNameWidth = Math.max(20, BAR_WIDTH - healthWidth - 8);
		String name = ellipsize(font, data.name, availableNameWidth);

		font.drawStringWithShadow(name, x, y, multiplyAlpha(TEXT, alpha));
		font.drawString(healthText, x + BAR_WIDTH - healthWidth, y, multiplyAlpha(MUTED_TEXT, alpha));
	}

	private static void drawHealthBar(HudData data, int x, int y, float alpha) {
		float safeHealth = Math.max(0.0F, data.health);
		float safeMaxHealth = Math.max(1.0F, data.maxHealth);
		float safeAbsorption = Math.max(0.0F, data.absorption);
		float scaleMax = safeMaxHealth + safeAbsorption;
		int healthWidth = clamp(Math.round(BAR_WIDTH * safeHealth / scaleMax), 0, BAR_WIDTH);
		int absorptionWidth = clamp(Math.round(BAR_WIDTH * safeAbsorption / scaleMax), 0, BAR_WIDTH - healthWidth);
		float healthRatio = safeHealth / safeMaxHealth;
		int healthColor = healthRatio <= 0.25F ? HEALTH_LOW : healthRatio <= 0.5F ? HEALTH_MEDIUM : HEALTH;

		if (healthWidth > 0) {
			Gui.drawRect(x, y, x + healthWidth, y + 7, multiplyAlpha(healthColor, alpha));
		}
		if (absorptionWidth > 0) {
			Gui.drawRect(x + healthWidth, y, x + healthWidth + absorptionWidth, y + 7, multiplyAlpha(ABSORPTION, alpha));
		}
	}

	private static void drawEquipment(Minecraft minecraft, FontRenderer font, HudData data, int x, int y) {
		int index = 1;
		for (int armorIndex = 0; armorIndex < data.armor.length; armorIndex++) {
			drawItem(minecraft, font, data.armor[armorIndex], x + armorIndex * 22, y, index++);
		}
		drawItem(minecraft, font, data.mainHand, x + data.armor.length * 22, y, index);
	}

	private static void drawItem(Minecraft minecraft, FontRenderer font, ItemStack stack, int x, int y, int index) {
		if (isEmpty(stack)) {
			return;
		}

		minecraft.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
		minecraft.getRenderItem().renderItemOverlayIntoGUI(font, stack, x, y, null);
	}

	private HudData smoothHealth(UUID targetId, HudData data, float delta) {
		if (!targetId.equals(smoothedTargetId)) {
			smoothedTargetId = targetId;
			displayedHealth = data.health;
		} else if (data.health < displayedHealth) {
			float progress = 1.0F - (float) Math.exp(-0.24F * delta);
			displayedHealth += (data.health - displayedHealth) * progress;
		} else {
			displayedHealth = data.health;
		}

		return data.withHealth(displayedHealth);
	}

	private static void drawOutline(int x, int y, int width, int height, int color) {
		Gui.drawRect(x, y, x + width, y + 1, color);
		Gui.drawRect(x, y + height - 1, x + width, y + height, color);
		Gui.drawRect(x, y, x + 1, y + height, color);
		Gui.drawRect(x + width - 1, y, x + width, y + height, color);
	}

	private static String ellipsize(FontRenderer font, String text, int maxWidth) {
		if (font.getStringWidth(text) <= maxWidth) {
			return text;
		}
		String suffix = "...";
		return font.trimStringToWidth(text, Math.max(0, maxWidth - font.getStringWidth(suffix))) + suffix;
	}

	private static String formatHealth(float value) {
		float rounded = Math.round(value * 10.0F) / 10.0F;
		return rounded == (int) rounded ? Integer.toString((int) rounded) : Float.toString(rounded);
	}

	private static float approach(float current, float target, float amount) {
		if (current < target) {
			return Math.min(target, current + amount);
		}
		return Math.max(target, current - amount);
	}

	private static float easeOutCubic(float value) {
		float inverse = 1.0F - clamp(value, 0.0F, 1.0F);
		return 1.0F - inverse * inverse * inverse;
	}

	private static int multiplyAlpha(int color, float alpha) {
		int resultAlpha = Math.round((color >>> 24) * clamp(alpha, 0.0F, 1.0F));
		return resultAlpha << 24 | color & 0x00FFFFFF;
	}

	private static boolean isEmpty(ItemStack stack) {
		return stack == null || stack.getItem() == null;
	}

	static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}

	static float clamp(float value, float min, float max) {
		return Math.max(min, Math.min(max, value));
	}

	private static final class TargetTracker {
		private UUID targetId;
		private EntityPlayer target;
		private int ticksRemaining;

		void tick(Minecraft minecraft, int retainTicks) {
			if (minecraft.theWorld == null || minecraft.thePlayer == null) {
				clear();
				return;
			}

			MovingObjectPosition hit = minecraft.objectMouseOver;
			if (hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && hit.entityHit instanceof EntityPlayer && hit.entityHit != minecraft.thePlayer) {
				focus((EntityPlayer) hit.entityHit, retainTicks);
				return;
			}

			if (targetId != null) {
				target = null;
				for (Object playerObject : minecraft.theWorld.playerEntities) {
					if (playerObject instanceof EntityPlayer) {
						EntityPlayer player = (EntityPlayer) playerObject;
						if (targetId.equals(player.getUniqueID())) {
							target = player;
							break;
						}
					}
				}
			}
			if (ticksRemaining > 0) {
				ticksRemaining--;
			}
			if (ticksRemaining <= 0 || target == null || target.isDead) {
				clear();
			}
		}

		void focus(EntityPlayer player, int retainTicks) {
			targetId = player.getUniqueID();
			target = player;
			ticksRemaining = retainTicks;
		}

		EntityPlayer getTarget() {
			return target;
		}

		private void clear() {
			targetId = null;
			target = null;
			ticksRemaining = 0;
		}
	}

	private static final class HudData {
		private final String name;
		private final ResourceLocation skin;
		private final float health;
		private final float maxHealth;
		private final float absorption;
		private final ItemStack[] armor;
		private final ItemStack mainHand;

		private HudData(String name, ResourceLocation skin, float health, float maxHealth, float absorption, ItemStack[] armor, ItemStack mainHand) {
			this.name = name;
			this.skin = skin;
			this.health = health;
			this.maxHealth = maxHealth;
			this.absorption = absorption;
			this.armor = armor;
			this.mainHand = mainHand;
		}

		private HudData withHealth(float health) {
			return new HudData(name, skin, health, maxHealth, absorption, armor, mainHand);
		}

		private static HudData fromPlayer(EntityPlayer player) {
			ItemStack[] armor = new ItemStack[4];
			for (int index = 0; index < armor.length; index++) {
				armor[index] = player.getCurrentArmor(armor.length - index - 1);
			}

			ResourceLocation skin = new ResourceLocation("textures/entity/steve.png");
			if (player instanceof AbstractClientPlayer) {
				skin = ((AbstractClientPlayer) player).getLocationSkin();
			}
			return new HudData(
					player.getName(),
					skin,
					Math.max(0.0F, player.getHealth()),
					Math.max(1.0F, player.getMaxHealth()),
					Math.max(0.0F, player.getAbsorptionAmount()),
					armor,
					player.getHeldItem()
			);
		}

		private static HudData sample() {
			return new HudData(
					"Player",
					DefaultPlayerSkin.getDefaultSkinLegacy(),
					17.0F,
					20.0F,
					2.0F,
					new ItemStack[]{
						damaged(Item.getByNameOrId("diamond_helmet"), 0.15F),
						damaged(Item.getByNameOrId("diamond_chestplate"), 0.35F),
						damaged(Item.getByNameOrId("diamond_leggings"), 0.55F),
						damaged(Item.getByNameOrId("diamond_boots"), 0.75F)
					},
					damaged(Item.getByNameOrId("diamond_sword"), 0.2F)
			);
		}

		private static ItemStack damaged(Item item, float damageRatio) {
			if (item == null) {
				return null;
			}
			ItemStack stack = new ItemStack(item);
			stack.setItemDamage(Math.round(stack.getMaxDamage() * damageRatio));
			return stack;
		}
	}
}
