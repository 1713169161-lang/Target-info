package com.sakiko.opponenthud.forge189;

import java.io.File;

import net.minecraftforge.common.config.Configuration;

final class ForgeHudConfig {
	private static final String CATEGORY = "hud";

	private Configuration configuration;
	private int x = 16;
	private int y = -1;
	private float scale = 1.0F;
	private int retainTicks = 60;

	private ForgeHudConfig() {
	}

	static ForgeHudConfig load(File file) {
		ForgeHudConfig config = new ForgeHudConfig();
		config.configuration = new Configuration(file);
		config.configuration.load();
		config.x = config.configuration.get(CATEGORY, "x", 16).getInt(16);
		config.y = config.configuration.get(CATEGORY, "y", -1).getInt(-1);
		config.scale = (float) config.configuration.get(CATEGORY, "scale", 1.0D).getDouble(1.0D);
		config.retainTicks = config.configuration.get(CATEGORY, "targetRetainTicks", 60).getInt(60);
		config.sanitize();
		config.save();
		return config;
	}

	ForgeHudConfig copy() {
		ForgeHudConfig copy = new ForgeHudConfig();
		copy.applyFrom(this);
		return copy;
	}

	void applyFrom(ForgeHudConfig source) {
		x = source.x;
		y = source.y;
		scale = source.scale;
		retainTicks = source.retainTicks;
		sanitize();
	}

	void reset() {
		x = 16;
		y = -1;
		scale = 1.0F;
		retainTicks = 60;
	}

	int x() {
		return x;
	}

	int y() {
		return y;
	}

	float scale() {
		return scale;
	}

	int retainTicks() {
		return retainTicks;
	}

	float retainSeconds() {
		return retainTicks / 20.0F;
	}

	void setX(int x) {
		this.x = Math.max(0, x);
	}

	void setY(int y) {
		this.y = Math.max(-1, y);
	}

	void setScale(float scale) {
		this.scale = clamp(scale, 0.5F, 2.0F);
	}

	void setRetainSeconds(float seconds) {
		retainTicks = clamp(Math.round(seconds * 20.0F), 0, 600);
	}

	void save() {
		if (configuration == null) {
			return;
		}

		configuration.get(CATEGORY, "x", 16).set(x);
		configuration.get(CATEGORY, "y", -1).set(y);
		configuration.get(CATEGORY, "scale", 1.0D).set(scale);
		configuration.get(CATEGORY, "targetRetainTicks", 60).set(retainTicks);
		if (configuration.hasChanged()) {
			configuration.save();
		}
	}

	private void sanitize() {
		x = Math.max(0, x);
		y = Math.max(-1, y);
		scale = clamp(scale, 0.5F, 2.0F);
		retainTicks = clamp(retainTicks, 0, 600);
	}

	private static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}

	private static float clamp(float value, float min, float max) {
		return Math.max(min, Math.min(max, value));
	}
}
