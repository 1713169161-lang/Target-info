# Opponent Status HUD - Forge 1.20.1

Forge 1.20.1 client-side target HUD. Point at, attack, or hit a player, animal, or monster with a local projectile to lock it; the HUD remains for the configured duration after leaving the target.

## Features

- Player, passive-mob, and monster targets
- Bow, crossbow, trident, and other local projectiles lock their entity target on impact
- Name, health, absorption, and a smooth health-loss animation
- Player skin head; a visible entity-type badge for non-player targets
- Armor, main hand, and offhand item displays whenever the target has equipment
- `H` toggles the HUD and `O` opens the in-game configuration screen
- Position, scale, and target-retention settings with drag-to-position preview

## Requirements

- Minecraft 1.20.1
- Minecraft Forge 47.4.22 or newer 47.x build
- Java 17

## Install

Place `opponent-status-hud-forge-1.20.1-1.1.0.jar` in the Forge instance's `mods` folder. The server does not need the mod.
