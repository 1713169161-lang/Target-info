package com.sakiko.opponenthud.forge1201;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

final class OpponentHudConfigScreen extends Screen {
	private static final int PANEL_MAX_WIDTH = 220;
	private static final int PANEL_HEIGHT = 164;
	private static final int MARGIN = 12;
	private static final int ROW_HEIGHT = 18;
	private static final int ROW_GAP = 4;
	private static final int SIDE_WIDTH = 20;
	private static final int BUTTON_GAP = 4;

	private final Screen parent;
	private final HudConfig savedConfig;
	private final HudConfig workingConfig;
	private final OpponentHudRenderer renderer;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private Button xValueButton;
	private Button yValueButton;
	private Button scaleValueButton;
	private Button retainValueButton;
	private boolean draggingPreview;
	private double dragOffsetX;
	private double dragOffsetY;

	OpponentHudConfigScreen(Screen parent, HudConfig config, OpponentHudRenderer renderer) {
		super(Component.literal("Opponent Status HUD"));
		this.parent = parent;
		this.savedConfig = config;
		this.workingConfig = config.copy();
		this.renderer = renderer;
	}

	@Override
	protected void init() {
		panelWidth = Math.min(PANEL_MAX_WIDTH, Math.max(176, width * 45 / 100));
		panelWidth = Math.min(panelWidth, Math.max(120, width - MARGIN * 2));
		panelX = Math.max(MARGIN, width - panelWidth - MARGIN);
		panelY = MARGIN;

		addRenderableWidget(Button.builder(title, button -> {}).bounds(panelX + 10, panelY + 7, panelWidth - 20, 18).build()).active = false;
		int rowY = panelY + 30;
		xValueButton = addAdjustmentRow(rowY, () -> shiftX(-1), () -> shiftX(1));
		yValueButton = addAdjustmentRow(rowY + ROW_HEIGHT + ROW_GAP, () -> shiftY(-1), () -> shiftY(1));
		scaleValueButton = addAdjustmentRow(rowY + (ROW_HEIGHT + ROW_GAP) * 2, () -> changeScale(-0.1F), () -> changeScale(0.1F));
		retainValueButton = addAdjustmentRow(rowY + (ROW_HEIGHT + ROW_GAP) * 3, () -> changeRetain(-1.0F), () -> changeRetain(1.0F));

		int buttonY = panelY + 133;
		int buttonWidth = Math.max(40, (panelWidth - 30) / 3);
		addRenderableWidget(Button.builder(Component.literal("Reset"), button -> reset()).bounds(panelX + 10, buttonY, buttonWidth, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Cancel"), button -> onClose()).bounds(panelX + 15 + buttonWidth, buttonY, buttonWidth, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Done"), button -> saveAndClose()).bounds(panelX + 20 + buttonWidth * 2, buttonY, buttonWidth, 20).build());
		refreshLabels();
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		renderBackground(graphics);
		renderer.renderPreview(graphics, workingConfig, width, height);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + PANEL_HEIGHT, 0xE512171C);
		drawOutline(graphics, panelX, panelY, panelWidth, PANEL_HEIGHT, 0xFF596873);
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
		if (mouseButton == 0 && isPreviewHovered(mouseX, mouseY) && !isInsidePanel(mouseX, mouseY)) {
			draggingPreview = true;
			dragOffsetX = mouseX - renderer.renderedX(workingConfig, width);
			dragOffsetY = mouseY - renderer.renderedY(workingConfig, height);
			return true;
		}
		return super.mouseClicked(mouseX, mouseY, mouseButton);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int mouseButton, double dragX, double dragY) {
		if (draggingPreview && mouseButton == 0) {
			float scale = workingConfig.scale();
			workingConfig.setX((int) Math.round((mouseX - dragOffsetX) / scale));
			workingConfig.setY((int) Math.round((mouseY - dragOffsetY) / scale));
			renderer.clampPosition(workingConfig, width, height);
			refreshLabels();
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, mouseButton, dragX, dragY);
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
		if (draggingPreview && mouseButton == 0) {
			draggingPreview = false;
			return true;
		}
		return super.mouseReleased(mouseX, mouseY, mouseButton);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private Button addAdjustmentRow(int y, Runnable decrease, Runnable increase) {
		int x = panelX + 10;
		int valueWidth = panelWidth - 20 - SIDE_WIDTH * 2 - BUTTON_GAP * 2;
		addRenderableWidget(Button.builder(Component.literal("<"), button -> decrease.run()).bounds(x, y, SIDE_WIDTH, ROW_HEIGHT).build());
		Button value = addRenderableWidget(Button.builder(Component.empty(), button -> {}).bounds(x + SIDE_WIDTH + BUTTON_GAP, y, valueWidth, ROW_HEIGHT).build());
		addRenderableWidget(Button.builder(Component.literal(">"), button -> increase.run()).bounds(x + SIDE_WIDTH + BUTTON_GAP + valueWidth + BUTTON_GAP, y, SIDE_WIDTH, ROW_HEIGHT).build());
		return value;
	}

	private void shiftX(int direction) {
		workingConfig.setX(workingConfig.x() + direction * positionStep(renderer.maxLogicalX(workingConfig, width)));
		renderer.clampPosition(workingConfig, width, height);
		refreshLabels();
	}

	private void shiftY(int direction) {
		workingConfig.setY(renderer.logicalY(workingConfig, height) + direction * positionStep(renderer.maxLogicalY(workingConfig, height)));
		renderer.clampPosition(workingConfig, width, height);
		refreshLabels();
	}

	private void changeScale(float change) {
		workingConfig.setScale(Math.round((workingConfig.scale() + change) * 10.0F) / 10.0F);
		renderer.clampPosition(workingConfig, width, height);
		refreshLabels();
	}

	private void changeRetain(float change) {
		workingConfig.setRetainSeconds(workingConfig.retainSeconds() + change);
		refreshLabels();
	}

	private void reset() {
		workingConfig.reset();
		renderer.clampPosition(workingConfig, width, height);
		refreshLabels();
	}

	private void saveAndClose() {
		savedConfig.applyFrom(workingConfig);
		savedConfig.save();
		minecraft.setScreen(parent);
	}

	private void refreshLabels() {
		if (xValueButton == null) {
			return;
		}
		xValueButton.setMessage(Component.literal("Horizontal position: " + workingConfig.x()));
		yValueButton.setMessage(Component.literal("Vertical position: " + renderer.logicalY(workingConfig, height)));
		scaleValueButton.setMessage(Component.literal("UI size: " + Math.round(workingConfig.scale() * 100.0F) + "%"));
		retainValueButton.setMessage(Component.literal("Target retention: " + Math.round(workingConfig.retainSeconds()) + " s"));
	}

	private boolean isPreviewHovered(double mouseX, double mouseY) {
		int previewX = renderer.renderedX(workingConfig, width);
		int previewY = renderer.renderedY(workingConfig, height);
		return mouseX >= previewX
				&& mouseX < previewX + renderer.renderedWidth(workingConfig)
				&& mouseY >= previewY
				&& mouseY < previewY + renderer.renderedHeight(workingConfig);
	}

	private boolean isInsidePanel(double mouseX, double mouseY) {
		return mouseX >= panelX && mouseX < panelX + panelWidth && mouseY >= panelY && mouseY < panelY + PANEL_HEIGHT;
	}

	private static int positionStep(int maximum) {
		return Math.max(1, Math.max(5, maximum / 20));
	}

	private static void drawOutline(GuiGraphics graphics, int x, int y, int width, int height, int color) {
		graphics.fill(x, y, x + width, y + 1, color);
		graphics.fill(x, y + height - 1, x + width, y + height, color);
		graphics.fill(x, y, x + 1, y + height, color);
		graphics.fill(x + width - 1, y, x + width, y + height, color);
	}
}
