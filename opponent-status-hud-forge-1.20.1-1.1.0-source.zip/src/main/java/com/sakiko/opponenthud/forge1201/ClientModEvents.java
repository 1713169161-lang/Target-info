package com.sakiko.opponenthud.forge1201;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = OpponentHudForge1201.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientModEvents {
	private static final HudConfig CONFIG = HudConfig.load();
	private static final TargetTracker TARGET_TRACKER = new TargetTracker(CONFIG);
	private static final OpponentHudRenderer RENDERER = new OpponentHudRenderer(TARGET_TRACKER, CONFIG);
	private static final KeyMapping TOGGLE_KEY = new KeyMapping(
			"key.opponenthud.toggle",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_H,
			"key.categories.opponenthud"
	);
	private static final KeyMapping CONFIG_KEY = new KeyMapping(
			"key.opponenthud.configure",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_O,
			"key.categories.opponenthud"
	);

	private ClientModEvents() {
	}

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(TOGGLE_KEY);
		event.register(CONFIG_KEY);
	}

	@SubscribeEvent
	public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
		event.registerAboveAll("target_status", (gui, graphics, partialTick, width, height) -> RENDERER.render(graphics, partialTick, width, height));
	}

	static void tick() {
		Minecraft client = Minecraft.getInstance();
		while (CONFIG_KEY.consumeClick()) {
			client.setScreen(new OpponentHudConfigScreen(client.screen, CONFIG, RENDERER));
		}
		while (TOGGLE_KEY.consumeClick()) {
			TARGET_TRACKER.toggle();
			if (client.player != null) {
				client.player.displayClientMessage(Component.literal(
						TARGET_TRACKER.isEnabled() ? "Opponent Status HUD: enabled" : "Opponent Status HUD: disabled"
				), true);
			}
		}
		TARGET_TRACKER.tick(client);
	}

	static void focusTarget(net.minecraft.world.entity.LivingEntity entity) {
		TARGET_TRACKER.focus(entity);
	}
}
