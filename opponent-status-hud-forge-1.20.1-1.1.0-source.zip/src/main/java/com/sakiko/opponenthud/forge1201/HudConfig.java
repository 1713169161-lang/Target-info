package com.sakiko.opponenthud.forge1201;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.logging.LogUtils;
import net.minecraft.util.Mth;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

final class HudConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final String FILE_NAME = "opponenthud-forge-1.20.1.json";

	private int x = 16;
	private int y = -1;
	private float scale = 1.0F;
	private int targetRetainTicks = 60;

	static HudConfig load() {
		Path path = configPath();
		if (Files.exists(path)) {
			try {
				HudConfig config = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), HudConfig.class);
				if (config != null) {
					config.sanitize();
					return config;
				}
			} catch (IOException | RuntimeException exception) {
				LOGGER.warn("Could not read Opponent Status HUD configuration {}; using defaults", path, exception);
			}
		}

		HudConfig config = new HudConfig();
		config.save();
		return config;
	}

	HudConfig copy() {
		HudConfig copy = new HudConfig();
		copy.applyFrom(this);
		return copy;
	}

	void applyFrom(HudConfig source) {
		x = source.x;
		y = source.y;
		scale = source.scale;
		targetRetainTicks = source.targetRetainTicks;
		sanitize();
	}

	void reset() {
		applyFrom(new HudConfig());
	}

	int x() {
		return x;
	}

	int y() {
		return y;
	}

	float scale() {
		return scale;
	}

	int retainTicks() {
		return targetRetainTicks;
	}

	float retainSeconds() {
		return targetRetainTicks / 20.0F;
	}

	void setX(int value) {
		x = Math.max(0, value);
	}

	void setY(int value) {
		y = Math.max(-1, value);
	}

	void setScale(float value) {
		scale = Mth.clamp(value, 0.5F, 2.0F);
	}

	void setRetainSeconds(float value) {
		targetRetainTicks = Mth.clamp(Math.round(value * 20.0F), 0, 600);
	}

	void save() {
		Path path = configPath();
		try {
			Files.createDirectories(path.getParent());
			Files.writeString(path, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException exception) {
			LOGGER.warn("Could not save Opponent Status HUD configuration {}", path, exception);
		}
	}

	private void sanitize() {
		x = Math.max(0, x);
		y = Math.max(-1, y);
		scale = Mth.clamp(scale, 0.5F, 2.0F);
		targetRetainTicks = Mth.clamp(targetRetainTicks, 0, 600);
	}

	private static Path configPath() {
		return FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);
	}
}
