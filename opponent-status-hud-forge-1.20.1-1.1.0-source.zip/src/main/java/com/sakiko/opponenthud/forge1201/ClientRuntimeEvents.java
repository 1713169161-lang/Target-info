package com.sakiko.opponenthud.forge1201;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = OpponentHudForge1201.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientRuntimeEvents {
	private ClientRuntimeEvents() {
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			ClientModEvents.tick();
		}
	}

	@SubscribeEvent
	public static void onAttack(AttackEntityEvent event) {
		Minecraft client = Minecraft.getInstance();
		Entity target = event.getTarget();
		if (event.getEntity().level().isClientSide && TargetTracker.isValidTarget(target, client)) {
			ClientModEvents.focusTarget((LivingEntity) target);
		}
	}

	@SubscribeEvent
	public static void onProjectileImpact(ProjectileImpactEvent event) {
		Minecraft client = Minecraft.getInstance();
		if (!event.getProjectile().level().isClientSide || event.getProjectile().getOwner() != client.player) {
			return;
		}

		if (event.getRayTraceResult() instanceof EntityHitResult hitResult
				&& TargetTracker.isValidTarget(hitResult.getEntity(), client)) {
			ClientModEvents.focusTarget((LivingEntity) hitResult.getEntity());
		}
	}
}
