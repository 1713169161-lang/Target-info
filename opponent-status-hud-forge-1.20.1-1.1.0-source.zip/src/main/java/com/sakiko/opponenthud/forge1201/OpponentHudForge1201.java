package com.sakiko.opponenthud.forge1201;

import net.minecraftforge.fml.common.Mod;

@Mod(OpponentHudForge1201.MOD_ID)
public final class OpponentHudForge1201 {
	public static final String MOD_ID = "opponenthud";

	public OpponentHudForge1201() {
	}
}
