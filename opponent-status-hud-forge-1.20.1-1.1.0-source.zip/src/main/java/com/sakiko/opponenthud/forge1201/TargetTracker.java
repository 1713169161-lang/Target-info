package com.sakiko.opponenthud.forge1201;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.EntityHitResult;

final class TargetTracker {
	private final HudConfig config;
	private LivingEntity target;
	private int ticksRemaining;
	private boolean enabled = true;

	TargetTracker(HudConfig config) {
		this.config = config;
	}

	void tick(Minecraft client) {
		if (client.level == null || client.player == null) {
			clear();
			return;
		}

		if (client.hitResult instanceof EntityHitResult hitResult && isValidTarget(hitResult.getEntity(), client)) {
			focus((LivingEntity) hitResult.getEntity());
			return;
		}

		if (ticksRemaining > 0) {
			ticksRemaining--;
		}
		if (ticksRemaining <= 0 || target == null || target.isRemoved() || target.level() != client.level) {
			clear();
		}
	}

	void focus(LivingEntity entity) {
		target = entity;
		ticksRemaining = config.retainTicks();
	}

	LivingEntity getTarget() {
		return enabled ? target : null;
	}

	boolean isEnabled() {
		return enabled;
	}

	void toggle() {
		enabled = !enabled;
	}

	static boolean isValidTarget(Entity entity, Minecraft client) {
		return entity instanceof LivingEntity
				&& entity != client.player
				&& !(entity instanceof ArmorStand)
				&& !entity.isSpectator();
	}

	private void clear() {
		target = null;
		ticksRemaining = 0;
	}
}
