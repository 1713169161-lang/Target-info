package com.sakiko.opponenthud.forge1201;

import java.util.Locale;
import java.util.UUID;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

final class OpponentHudRenderer {
	static final int PANEL_WIDTH = 230;
	static final int PANEL_HEIGHT = 62;

	private static final int HEAD_SIZE = 38;
	private static final int BAR_WIDTH = 168;
	private static final int HEAD_BACKGROUND = 0xFF0A0D10;
	private static final int HEAD_BORDER = 0xFF4A5863;
	private static final int TEXT = 0xFFF5F7F8;
	private static final int MUTED_TEXT = 0xFFB8C3C9;
	private static final int HEALTH = 0xFF18C7D9;
	private static final int HEALTH_MEDIUM = 0xFFFFB300;
	private static final int HEALTH_LOW = 0xFFEF5350;
	private static final int ABSORPTION = 0xFFFFC43D;
	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD,
			EquipmentSlot.CHEST,
			EquipmentSlot.LEGS,
			EquipmentSlot.FEET
	};

	private final TargetTracker targetTracker;
	private final HudConfig config;
	private HudData lastRenderedData;
	private UUID smoothedTargetId;
	private float displayedHealth;
	private float visibility;

	OpponentHudRenderer(TargetTracker targetTracker, HudConfig config) {
		this.targetTracker = targetTracker;
		this.config = config;
	}

	void render(GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
		Minecraft client = Minecraft.getInstance();
		LivingEntity target = targetTracker.getTarget();
		boolean shouldShow = target != null && client.player != null && !client.options.hideGui;
		float delta = Mth.clamp(client.getFrameTime(), 0.0F, 5.0F);

		if (shouldShow) {
			lastRenderedData = smoothHealth(target.getUUID(), HudData.fromEntity(target), delta);
		}

		if (lastRenderedData == null) {
			return;
		}

		float response = shouldShow ? 0.32F : 0.24F;
		float progress = 1.0F - (float) Math.exp(-response * delta);
		visibility = Mth.lerp(progress, visibility, shouldShow ? 1.0F : 0.0F);
		if (visibility <= 0.01F) {
			visibility = 0.0F;
			if (!shouldShow) {
				lastRenderedData = null;
			}
			return;
		}

		renderConfigured(graphics, lastRenderedData, config, visibility, screenWidth, screenHeight);
	}

	void renderPreview(GuiGraphics graphics, HudConfig previewConfig, int screenWidth, int screenHeight) {
		LivingEntity target = targetTracker.getTarget();
		HudData data = target == null ? HudData.sample() : HudData.fromEntity(target);
		renderConfigured(graphics, data, previewConfig, 1.0F, screenWidth, screenHeight);
	}

	void clampPosition(HudConfig targetConfig, int screenWidth, int screenHeight) {
		targetConfig.setX(Mth.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth)));
		if (targetConfig.y() >= 0) {
			targetConfig.setY(Mth.clamp(targetConfig.y(), 0, maxLogicalY(targetConfig, screenHeight)));
		}
	}

	int maxLogicalX(HudConfig targetConfig, int screenWidth) {
		return Math.max(0, (int) (screenWidth / targetConfig.scale()) - PANEL_WIDTH);
	}

	int maxLogicalY(HudConfig targetConfig, int screenHeight) {
		return Math.max(0, (int) (screenHeight / targetConfig.scale()) - PANEL_HEIGHT);
	}

	int logicalX(HudConfig targetConfig, int screenWidth) {
		return Mth.clamp(targetConfig.x(), 0, maxLogicalX(targetConfig, screenWidth));
	}

	int logicalY(HudConfig targetConfig, int screenHeight) {
		int requestedY = targetConfig.y() < 0 ? maxLogicalY(targetConfig, screenHeight) / 2 : targetConfig.y();
		return Mth.clamp(requestedY, 0, maxLogicalY(targetConfig, screenHeight));
	}

	int renderedX(HudConfig targetConfig, int screenWidth) {
		return Math.round(logicalX(targetConfig, screenWidth) * targetConfig.scale());
	}

	int renderedY(HudConfig targetConfig, int screenHeight) {
		return Math.round(logicalY(targetConfig, screenHeight) * targetConfig.scale());
	}

	int renderedWidth(HudConfig targetConfig) {
		return Math.round(PANEL_WIDTH * targetConfig.scale());
	}

	int renderedHeight(HudConfig targetConfig) {
		return Math.round(PANEL_HEIGHT * targetConfig.scale());
	}

	private static void renderConfigured(
			GuiGraphics graphics,
			HudData data,
			HudConfig targetConfig,
			float alpha,
			int screenWidth,
			int screenHeight
	) {
		float scale = targetConfig.scale();
		int scaledWidth = Math.max(PANEL_WIDTH, (int) (screenWidth / scale));
		int scaledHeight = Math.max(PANEL_HEIGHT, (int) (screenHeight / scale));
		int x = Mth.clamp(targetConfig.x(), 0, scaledWidth - PANEL_WIDTH);
		int requestedY = targetConfig.y() < 0 ? (scaledHeight - PANEL_HEIGHT) / 2 : targetConfig.y();
		int y = Mth.clamp(requestedY, 0, scaledHeight - PANEL_HEIGHT);
		float eased = easeOutCubic(alpha);

		PoseStack pose = graphics.pose();
		pose.pushPose();
		pose.scale(scale, scale, 1.0F);
		float centerX = x + PANEL_WIDTH / 2.0F;
		float centerY = y + PANEL_HEIGHT / 2.0F;
		pose.translate(centerX - (1.0F - eased) * 12.0F, centerY, 0.0F);
		pose.scale(0.90F + eased * 0.10F, 0.90F + eased * 0.10F, 1.0F);
		pose.translate(-centerX, -centerY, 0.0F);

		Font font = Minecraft.getInstance().font;
		drawHead(graphics, font, data, x + 8, y + 12, alpha);
		drawNameAndHealth(graphics, font, data, x + 55, y + 8, alpha);
		drawHealthBar(graphics, data, x + 55, y + 23, alpha);
		drawEquipment(graphics, font, data, x + 55, y + 38);
		pose.popPose();
	}

	private static void drawHead(GuiGraphics graphics, Font font, HudData data, int x, int y, float alpha) {
		graphics.fill(x - 2, y - 2, x + HEAD_SIZE + 2, y + HEAD_SIZE + 2, multiplyAlpha(HEAD_BACKGROUND, alpha));
		drawOutline(graphics, x - 1, y - 1, HEAD_SIZE + 2, HEAD_SIZE + 2, multiplyAlpha(HEAD_BORDER, alpha));
		if (data.playerSkin != null) {
			PlayerFaceRenderer.draw(graphics, data.playerSkin, x, y, HEAD_SIZE);
			return;
		}

		int accent = multiplyAlpha(data.entityAccent, alpha);
		graphics.fill(x + 3, y + 3, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, multiplyAlpha(0xFF18232B, alpha));
		graphics.fill(x + 3, y + HEAD_SIZE - 7, x + HEAD_SIZE - 3, y + HEAD_SIZE - 3, accent);
		graphics.drawCenteredString(font, entityInitial(data.name), x + HEAD_SIZE / 2, y + 13, multiplyAlpha(TEXT, alpha));
	}

	private static void drawNameAndHealth(GuiGraphics graphics, Font font, HudData data, int x, int y, float alpha) {
		String healthText = data.absorption > 0.0F
				? formatHealth(data.health) + " +" + formatHealth(data.absorption)
				: formatHealth(data.health) + " / " + formatHealth(data.maxHealth);
		int healthWidth = font.width(healthText);
		String name = ellipsize(font, data.name, Math.max(20, BAR_WIDTH - healthWidth - 8));

		graphics.drawString(font, name, x, y, multiplyAlpha(TEXT, alpha), true);
		graphics.drawString(font, healthText, x + BAR_WIDTH - healthWidth, y, multiplyAlpha(MUTED_TEXT, alpha), false);
	}

	private static void drawHealthBar(GuiGraphics graphics, HudData data, int x, int y, float alpha) {
		float safeHealth = Math.max(0.0F, data.health);
		float safeMaxHealth = Math.max(1.0F, data.maxHealth);
		float safeAbsorption = Math.max(0.0F, data.absorption);
		float scaleMax = safeMaxHealth + safeAbsorption;
		int healthWidth = Mth.clamp(Math.round(BAR_WIDTH * safeHealth / scaleMax), 0, BAR_WIDTH);
		int absorptionWidth = Mth.clamp(Math.round(BAR_WIDTH * safeAbsorption / scaleMax), 0, BAR_WIDTH - healthWidth);
		float healthRatio = safeHealth / safeMaxHealth;
		int healthColor = healthRatio <= 0.25F ? HEALTH_LOW : healthRatio <= 0.5F ? HEALTH_MEDIUM : HEALTH;

		if (healthWidth > 0) {
			graphics.fill(x, y, x + healthWidth, y + 7, multiplyAlpha(healthColor, alpha));
		}
		if (absorptionWidth > 0) {
			graphics.fill(x + healthWidth, y, x + healthWidth + absorptionWidth, y + 7, multiplyAlpha(ABSORPTION, alpha));
		}
	}

	private static void drawEquipment(GuiGraphics graphics, Font font, HudData data, int x, int y) {
		for (int index = 0; index < data.armor.length; index++) {
			drawItem(graphics, font, data.armor[index], x + index * 22, y);
		}
		drawItem(graphics, font, data.mainHand, x + data.armor.length * 22, y);
		drawItem(graphics, font, data.offHand, x + (data.armor.length + 1) * 22, y);
	}

	private static void drawItem(GuiGraphics graphics, Font font, ItemStack stack, int x, int y) {
		if (stack.isEmpty()) {
			return;
		}
		graphics.renderItem(stack, x, y);
		graphics.renderItemDecorations(font, stack, x, y);
	}

	private HudData smoothHealth(UUID targetId, HudData data, float delta) {
		if (!targetId.equals(smoothedTargetId)) {
			smoothedTargetId = targetId;
			displayedHealth = data.health;
		} else if (data.health < displayedHealth) {
			float progress = 1.0F - (float) Math.exp(-0.24F * delta);
			displayedHealth = Mth.lerp(progress, displayedHealth, data.health);
		} else {
			displayedHealth = data.health;
		}
		return data.withHealth(displayedHealth);
	}

	private static void drawOutline(GuiGraphics graphics, int x, int y, int width, int height, int color) {
		graphics.fill(x, y, x + width, y + 1, color);
		graphics.fill(x, y + height - 1, x + width, y + height, color);
		graphics.fill(x, y, x + 1, y + height, color);
		graphics.fill(x + width - 1, y, x + width, y + height, color);
	}

	private static String entityInitial(String name) {
		return name == null || name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
	}

	private static int entityAccent(LivingEntity entity) {
		int hash = entity.getType().getDescriptionId().hashCode();
		return 0xFF000000 | 0x60 << 16 | ((hash >>> 8) & 0x7F) << 8 | (0x80 | hash & 0x7F);
	}

	private static float easeOutCubic(float value) {
		float inverse = 1.0F - Mth.clamp(value, 0.0F, 1.0F);
		return 1.0F - inverse * inverse * inverse;
	}

	private static int multiplyAlpha(int color, float amount) {
		int alpha = Math.round((color >>> 24) * Mth.clamp(amount, 0.0F, 1.0F));
		return alpha << 24 | color & 0x00FFFFFF;
	}

	private static String ellipsize(Font font, String text, int maxWidth) {
		if (font.width(text) <= maxWidth) {
			return text;
		}
		String suffix = "...";
		return font.plainSubstrByWidth(text, Math.max(0, maxWidth - font.width(suffix))) + suffix;
	}

	private static String formatHealth(float value) {
		float rounded = Math.round(value * 10.0F) / 10.0F;
		return rounded == (int) rounded ? Integer.toString((int) rounded) : Float.toString(rounded);
	}

	private static final class HudData {
		private final String name;
		private final ResourceLocation playerSkin;
		private final int entityAccent;
		private final float health;
		private final float maxHealth;
		private final float absorption;
		private final ItemStack[] armor;
		private final ItemStack mainHand;
		private final ItemStack offHand;

		private HudData(String name, ResourceLocation playerSkin, int entityAccent, float health, float maxHealth, float absorption, ItemStack[] armor, ItemStack mainHand, ItemStack offHand) {
			this.name = name;
			this.playerSkin = playerSkin;
			this.entityAccent = entityAccent;
			this.health = health;
			this.maxHealth = maxHealth;
			this.absorption = absorption;
			this.armor = armor;
			this.mainHand = mainHand;
			this.offHand = offHand;
		}

		private HudData withHealth(float health) {
			return new HudData(name, playerSkin, entityAccent, health, maxHealth, absorption, armor, mainHand, offHand);
		}

		private static HudData fromEntity(LivingEntity entity) {
			ItemStack[] armor = new ItemStack[ARMOR_SLOTS.length];
			for (int index = 0; index < ARMOR_SLOTS.length; index++) {
				armor[index] = entity.getItemBySlot(ARMOR_SLOTS[index]);
			}

			ResourceLocation skin = null;
			if (entity instanceof AbstractClientPlayer player) {
				skin = player.getSkinTextureLocation();
			}
			return new HudData(
					entity.getName().getString(),
					skin,
					entityAccent(entity),
					Math.max(0.0F, entity.getHealth()),
					Math.max(1.0F, entity.getMaxHealth()),
					Math.max(0.0F, entity.getAbsorptionAmount()),
					armor,
					entity.getMainHandItem(),
					entity.getOffhandItem()
			);
		}

		private static HudData sample() {
			return new HudData(
					"Player",
					DefaultPlayerSkin.getDefaultSkin(new UUID(0L, 0L)),
					0xFF18C7D9,
					17.0F,
					20.0F,
					2.0F,
					new ItemStack[]{
						damaged(Items.DIAMOND_HELMET, 0.15F),
						damaged(Items.DIAMOND_CHESTPLATE, 0.35F),
						damaged(Items.DIAMOND_LEGGINGS, 0.55F),
						damaged(Items.DIAMOND_BOOTS, 0.75F)
					},
					damaged(Items.DIAMOND_SWORD, 0.2F),
					damaged(Items.SHIELD, 0.35F)
			);
		}

		private static ItemStack damaged(Item item, float damageRatio) {
			ItemStack stack = new ItemStack(item);
			stack.setDamageValue(Math.round(stack.getMaxDamage() * damageRatio));
			return stack;
		}
	}
}
